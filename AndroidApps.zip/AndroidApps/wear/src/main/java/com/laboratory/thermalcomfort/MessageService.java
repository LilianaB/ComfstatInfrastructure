package com.laboratory.thermalcomfort;

import android.app.IntentService;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.wearable.Wearable;

import static com.laboratory.thermalcomfort.utils.Constants.*;



/**
 * Created by Liliana Barrios on 24/11/15.
 */
public class MessageService extends IntentService {

    private static final String TAG = MessageService.class.getSimpleName();
    private static final int CONNECTION_TIME_OUT_MS = 100;

    public MessageService() {
        super("MessageService" );
    }


    @Override
    protected void onHandleIntent(Intent intent) {

        Bundle extras = intent.getExtras();
        String nodeId = extras.getString(NODE_ID);
        String path = extras.getString(PATH);
        int heartRate = extras.getInt(HEART_RATE);
        double elapsedTime = extras.getDouble(ELAPSED_TIME);
        String accuracy = extras.getString(ACCURACY);

        String battery = getCurrentBatteryLevel()+"";
        String message = heartRate +TOKEN+ battery +TOKEN+ elapsedTime +TOKEN+ accuracy;

        Log.d(TAG, "In background wear " + message);

        GoogleApiClient client = new GoogleApiClient.Builder(getApplicationContext())
                .addApi(Wearable.API)
                .build();
        client.blockingConnect(CONNECTION_TIME_OUT_MS, TimeUnit.MILLISECONDS);
        Wearable.MessageApi.sendMessage(client, nodeId, path, message.getBytes());
        client.disconnect();

    }

    private float getCurrentBatteryLevel() {
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);
        int level = Objects.requireNonNull(batteryStatus).getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        float batteryPct = level / (float)scale;
        Log.d(TAG, "Battery level " + batteryPct);

        return batteryPct;
    }
}
