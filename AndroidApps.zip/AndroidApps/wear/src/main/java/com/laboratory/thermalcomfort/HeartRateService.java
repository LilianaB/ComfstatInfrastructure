package com.laboratory.thermalcomfort;

import android.app.IntentService;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import static com.laboratory.thermalcomfort.utils.Constants.*;
import static android.support.v4.content.WakefulBroadcastReceiver.completeWakefulIntent;

/**
 * Created by Liliana Barrios on 07/11/15.
 */
public class   HeartRateService extends IntentService implements SensorEventListener {

    private static final String TAG = HeartRateService.class.getSimpleName();


    private SensorManager mSensorManager = null;
    private Sensor mSensor = null;
    private String mNodeId;
    private String mPath;
    private Intent mIntent;
    private long mStartTime;
    private int mEventCounter;


    public HeartRateService() {
        super("HeartRateService" );
    }

    @Override
    protected void onHandleIntent(Intent workIntent) {

        mStartTime = System.nanoTime();
        Log.d(TAG, "onHandleIntent. " + "Star service @ " + mStartTime);

        mIntent = workIntent;
        mEventCounter = 0;
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
        mSensorManager.registerListener(this, mSensor,
                SensorManager.SENSOR_DELAY_NORMAL);

        Bundle extras = workIntent.getExtras();
        mNodeId = extras.getString(NODE_ID);
        mPath = extras.getString(PATH);

    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // do nothing
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        // If the sensor data is unreliable return
        if (event.accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE)
        {
            //Toast.makeText(main.this, "Sensor Status Unreliable",Toast.LENGTH_SHORT).show();
            return;
        }

        if (event.sensor.getType() == Sensor.TYPE_HEART_RATE) {

            checkStatus(event);

            int heartRateCounter = (int) event.values[0];
            Log.d(TAG, "Current Heart rate " + heartRateCounter + " " + mEventCounter);
            if (mEventCounter < TIMEOUT) {

                if (heartRateCounter != 0) {
                    Log.d(TAG, "Heart rate not null: " + heartRateCounter);

                    // stop the sensor
                    mSensorManager.unregisterListener(this);

                    Intent mServiceIntent = new Intent(getApplicationContext(), MessageService.class);
                    mServiceIntent.putExtra(NODE_ID, mNodeId);
                    mServiceIntent.putExtra(PATH, mPath);
                    mServiceIntent.putExtra(HEART_RATE, heartRateCounter);
                    mServiceIntent.putExtra(ELAPSED_TIME, getSensorElapsedTime());
                    mServiceIntent.putExtra(ACCURACY,checkStatus(event));

                    //release wake lock
                    completeWakefulIntent(mIntent);
                    //start messaging service
                    startService(mServiceIntent);
                }
            } else {
                //after 5 iterations no value was received, assumed person is not using watch
                // stop the sensor
                mSensorManager.unregisterListener(this);

                //cancel listener
                Intent mServiceIntent = new Intent(getApplicationContext(), MessageService.class);
                mServiceIntent.putExtra(NODE_ID, mNodeId);
                mServiceIntent.putExtra(PATH, DISCONNECT_PATH);
                mServiceIntent.putExtra(HEART_RATE, heartRateCounter);
                mServiceIntent.putExtra(ELAPSED_TIME, getSensorElapsedTime());
                mServiceIntent.putExtra(ACCURACY,checkStatus(event));

                //release wake lock
                completeWakefulIntent(mIntent);
                //start messaging service
                startService(mServiceIntent);

            }
            mEventCounter++;
        }
    }

    private String checkStatus(SensorEvent event) {

        String status = "";

        // If the sensor data is unreliable return
        switch (event.accuracy) {
            case SensorManager.SENSOR_STATUS_UNRELIABLE:
                status = UNRELIABLE;
                break;
            case SensorManager.SENSOR_STATUS_NO_CONTACT:
                status = NO_CONTACT;
                break;
            case SensorManager.SENSOR_STATUS_ACCURACY_HIGH:
                status = HIGH;
                break;
            case SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM:
                status = MEDIUM;
                break;
            case SensorManager.SENSOR_STATUS_ACCURACY_LOW:
                status = LOW;
                break;
            default:
                break;
        }
        return status;
    }

    private double getSensorElapsedTime() {

        long endtime = System.nanoTime();
        Log.i(TAG, "Completed service @ " + endtime);
        long elapsedTime = (endtime - mStartTime);
        double seconds = (double)elapsedTime / 1000000000.0;
        Log.d(TAG, "sensor time "+ seconds);

        return seconds;

    }




}