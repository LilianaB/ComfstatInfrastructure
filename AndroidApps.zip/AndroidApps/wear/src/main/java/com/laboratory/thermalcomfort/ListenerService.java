package com.laboratory.thermalcomfort;

import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import static com.laboratory.thermalcomfort.utils.Constants.*;

/**
 * Created by Liliana Barrios on 06/11/15.
 */
public class ListenerService extends WearableListenerService {

    private static final String TAG = ListenerService.class.getSimpleName();

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {

        String nodeId = messageEvent.getSourceNodeId();
        showToast(messageEvent.getPath());
        String sms = new String(messageEvent.getData());
        Log.d(TAG, "Received on watch: " + sms);

        Intent mServiceIntent = new Intent(getApplicationContext(), HeartRateService.class);
        mServiceIntent.putExtra(NODE_ID, nodeId);
        mServiceIntent.putExtra(PATH, messageEvent.getPath());
        WakefulBroadcastReceiver.startWakefulService(this, mServiceIntent);
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

}
