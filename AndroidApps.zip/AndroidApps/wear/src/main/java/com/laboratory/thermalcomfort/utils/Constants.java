package com.laboratory.thermalcomfort.utils;

import android.hardware.SensorManager;
import android.util.Log;

/**
 * Created by Liliana Barrios on 24/11/15.
 */
public class Constants {

    public static final String PATH = "PATH";
    public static final String NODE_ID = "NODE_ID";
    public static final String HEART_RATE = "HEART_RATE";
    public static final String ELAPSED_TIME ="ELAPSED_TIME";
    public static final String ACCURACY ="ACCURACY";
    public static final String DISCONNECT_PATH ="/disconnect";
    public static final String TOKEN = "|";
    public static  final int TIMEOUT = 10; //10 secs timeout limit

    public static final String UNRELIABLE = "unreliable";
    public static final String NO_CONTACT = "no_contact";
    public static final String HIGH = "high";
    public static final String MEDIUM = "medium";
    public static final String LOW = "low";

}
