package com.laboratory.thermalcomfort.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.alarm.NotificationAlarmReceiver;
import com.laboratory.thermalcomfort.alarm.HeartRateAlarmReceiver;

/**
 * Created by Liliana Barrios on 17/11/15.
 */
public class SessionUtil {

    public static int getCurrentUserId(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        return sharedPref.getInt(context.getString(R.string.pref_current_user_id), 0);
    }

    public void startServices(Context context, String TAG) {

        NotificationAlarmReceiver notificationAlarmReceiver = new NotificationAlarmReceiver();
        HeartRateAlarmReceiver hRAlarmReceiver = new HeartRateAlarmReceiver();

        SharedPreferences myPreference= PreferenceManager.getDefaultSharedPreferences(context);
        String heartRateFrequency = myPreference.getString("heart", "none");
        String notificationFrequency = myPreference.getString("frequency", "none");
        Log.d(TAG, heartRateFrequency + " " + notificationFrequency);

        notificationAlarmReceiver.setAlarm(context, notificationFrequency);
        hRAlarmReceiver.setAlarm(context, heartRateFrequency);


    }
}
