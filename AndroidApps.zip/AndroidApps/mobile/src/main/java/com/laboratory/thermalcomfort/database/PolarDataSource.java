package com.laboratory.thermalcomfort.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import com.laboratory.thermalcomfort.models.Polar;
import com.laboratory.thermalcomfort.utils.TimeUtil;

import java.util.ArrayList;

/**
 * Created by Liliana Barrios on 22/02/16.
 */
public class PolarDataSource {

    private DBSqliteHelper mDBSqliteHelper;
    private static final String TAG = PolarDataSource.class.getSimpleName();

    public PolarDataSource(Context context) {
        mDBSqliteHelper = new DBSqliteHelper(context);
    }

    private SQLiteDatabase open() {
        return mDBSqliteHelper.getWritableDatabase();
    }

    private void close(SQLiteDatabase db) {
        db.close();
    }

    public  ArrayList<Polar> read() {
        SQLiteDatabase db = open();
        Cursor cursor = db.query(
                DBSqliteHelper.POLAR_TABLE,
                new String[]{DBSqliteHelper.COLUMN_POLAR_HR, BaseColumns._ID, DBSqliteHelper.COLUMN_POLAR_RR_INTERVAL, DBSqliteHelper.COLUMN_POLAR_CREATION_DATE
                        , DBSqliteHelper.COLUMN_POLAR_SYNC},
                null, //selection
                null, //selection args
                null, //group by
                null, //having
                null); //order

        ArrayList<Polar> polarRecords = new ArrayList<Polar>();
        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                Polar polar = new Polar(getIntFromColumnName(cursor, BaseColumns._ID),
                        getIntFromColumnName(cursor, DBSqliteHelper.COLUMN_POLAR_HR),
                        getStringFromColumnName(cursor, DBSqliteHelper.COLUMN_POLAR_RR_INTERVAL),
                        getLongFromColumnName(cursor, DBSqliteHelper.COLUMN_POLAR_CREATION_DATE),
                        getIntFromColumnName(cursor, DBSqliteHelper.COLUMN_POLAR_SYNC)
                );
                polarRecords.add(polar);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();
        db.close();
        return polarRecords;
    }

    public  Cursor getCursor() {

        SQLiteDatabase db = open();

        String whereClause = DBSqliteHelper.COLUMN_POLAR_SYNC + "=?";

        Cursor cursor = db.query(
                DBSqliteHelper.POLAR_TABLE,
                new String[]{DBSqliteHelper.COLUMN_POLAR_HR, BaseColumns._ID, DBSqliteHelper.COLUMN_POLAR_RR_INTERVAL, DBSqliteHelper.COLUMN_POLAR_CREATION_DATE
                        , DBSqliteHelper.COLUMN_POLAR_SYNC},
                whereClause,
                new String[] {String.valueOf(0)},
                null, //group by
                null, //having
                null); //order
        //db.close();
        return cursor;
    }

    public void update(Cursor cursor) {
        Log.d(TAG, "Updating Records");

        SQLiteDatabase db = open();
        db.beginTransaction();

        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                int recordId = getIntFromColumnName(cursor, BaseColumns._ID);
                ContentValues cv = new ContentValues();
                cv.put(DBSqliteHelper.COLUMN_POLAR_SYNC,1);
                db.update(DBSqliteHelper.POLAR_TABLE,
                        cv,
                        "_id="+recordId,
                        null);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();

        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

    public void create(Polar polar) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        ContentValues polarValues = new ContentValues();
        polarValues.put(DBSqliteHelper.COLUMN_POLAR_HR, polar.getHeartRate());
        polarValues.put(DBSqliteHelper.COLUMN_POLAR_RR_INTERVAL, polar.getRRInterval());
        polarValues.put(DBSqliteHelper.COLUMN_POLAR_CREATION_DATE, polar.getCreationDate());
        polarValues.put(DBSqliteHelper.COLUMN_POLAR_SYNC, 0);
        long memeID = db.insert(DBSqliteHelper.POLAR_TABLE, null, polarValues);

        db.setTransactionSuccessful();
        db.endTransaction();
        close(db);

    }

    private int getIntFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getInt(columnIndex);
    }

    private String getStringFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getString(columnIndex);

    }
    private Long getLongFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getLong(columnIndex);
    }

    public void delete(int polarId) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        //String format is the where clause of the query
        db.delete(DBSqliteHelper.POLAR_TABLE,
                String.format("%s=%s", BaseColumns._ID,
                        String.valueOf(polarId)),
                null);
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

}
