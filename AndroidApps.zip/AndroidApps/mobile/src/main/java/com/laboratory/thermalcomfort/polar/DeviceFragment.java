package com.laboratory.thermalcomfort.polar;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.laboratory.thermalcomfort.R;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.laboratory.thermalcomfort.utils.Constants.EXTRAS_DEVICE_ADDRESS;
import static com.laboratory.thermalcomfort.utils.Constants.EXTRAS_DEVICE_NAME;

/**
 * Created by Liliana Barrios on 17/02/16.
 */
public class DeviceFragment extends Fragment {

    private static final String TAG = DeviceFragment.class.getSimpleName();

    @Bind(R.id.cancelImageView) ImageView mCancel;
    @Bind(R.id.deviceName) TextView mDeviceNameTextView;
    @Bind(R.id.deviceAddress) TextView mDeviceAddressTextView;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bluetooth_device_fragment_layout, container, false);
        ButterKnife.bind(this, view);

        String deviceName = getArguments().getString(EXTRAS_DEVICE_NAME);
        String deviceAddress = getArguments().getString(EXTRAS_DEVICE_ADDRESS);

        mDeviceNameTextView.setText(deviceName);
        mDeviceAddressTextView.setText(deviceAddress);
        saveSessionValues(true);

        return view;
    }

    @OnClick(R.id.cancelImageView)
    public void cancelSelection() {
        Intent gattServiceIntent = new Intent(getActivity(), PolarBluetoothLeService.class);
        getActivity().stopService(gattServiceIntent);

        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        NoDeviceFragment deviceFragment = new NoDeviceFragment();
        fragmentTransaction.replace(R.id.fragment_container, deviceFragment);
        fragmentTransaction.commit();

        saveSessionValues(false);
    }

    private void saveSessionValues( boolean isLogged) {
        SharedPreferences sharedPref = getActivity().getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(getString(R.string.pref_bluetooth_device_state), isLogged);
        editor.commit();
    }

}
