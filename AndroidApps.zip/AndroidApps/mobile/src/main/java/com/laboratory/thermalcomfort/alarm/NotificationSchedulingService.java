package com.laboratory.thermalcomfort.alarm;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.app.RemoteInput;
import android.util.Log;

import com.laboratory.thermalcomfort.utils.NotificationUtil;
import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.ThermalComfortActivity;

/**
 * Created by Liliana Barrios on 09/10/15.
 */
public class NotificationSchedulingService extends IntentService {

    public NotificationSchedulingService() {
        super("NotificationSchedulingService");
    }

    public static final String TAG = NotificationSchedulingService.class.getSimpleName();
    // An ID used to post the notification.
    public static final int NOTIFICATION_ID = 1;
    private boolean mIsVibrateActive;
    private boolean mIsLocalOnly;

    @Override
    protected void onHandleIntent(Intent intent) {

        getUserPreferences();
        sendNotification();
        // Release the wake lock provided by the castReceiver.
        NotificationAlarmReceiver.completeWakefulIntent(intent);
    }

    // Post a notification to remind user for feedback
    private void sendNotification() {
        NotificationManager mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, ThermalComfortActivity.class), 0);

        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.mipmap.ic_vote_notification)
                        .setContentTitle(getString(R.string.notification_title))
                        .setStyle(new NotificationCompat.BigTextStyle()
                                .bigText(getString(R.string.notification_content)))
                        .setContentText(getString(R.string.notification_content))
                        .setAutoCancel(true)
                        .setColor(Color.parseColor("#0BBCD3"))
                        .setContentIntent(contentIntent)
                        .setSound(sound);

        if (mIsLocalOnly) {
            builder.setLocalOnly(true);
            Log.d(TAG, "Deactivate smartwatch notifications");
        }
        if (mIsVibrateActive) {
            builder.setVibrate(new long[] {0, 100, 50, 100} );
            Log.d(TAG, "Activate notifications vibration");
        }

        // Extend the notification builder with the second page
        RemoteInput remoteInput = new RemoteInput.Builder(NotificationUtil.EXTRA_REPLY)
                .setLabel("Comfort level")
                .setAllowFreeFormInput(false)
                .setChoices(new String[]{getString(R.string.feeling_cold),
                        getString(R.string.feeling_cool),
                        getString(R.string.feeling_slightly_cool),
                        getString(R.string.feeling_neutral),
                        getString(R.string.feeling_slightly_warm),
                        getString(R.string.feeling_warm),
                        getString(R.string.feeling_hot)})
                .build();

        NotificationCompat.Action action = new NotificationCompat.Action.Builder(
                R.drawable.ic_full_reply,
                getApplicationContext().getString(R.string.example_reply_action),
                NotificationUtil.getPendingIntent(getApplicationContext(),
                        R.string.example_reply_action_clicked))
                .addRemoteInput(remoteInput)
                .build();


        Bitmap wearableBackground = BitmapFactory.decodeResource(getResources(), R.drawable.img2);
        Notification notification = builder
                .extend(new NotificationCompat.WearableExtender()
                        .addAction(action)
                        .setBackground(wearableBackground)
                )
                .setAutoCancel(true)
                .build();

        // Issue the notification
        NotificationManagerCompat notificationManager =
                NotificationManagerCompat.from(this);

        mNotificationManager.notify(NOTIFICATION_ID, notification);
    }

    private void getUserPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        mIsVibrateActive = sharedPreferences.getBoolean("vibrate_enabled", false);
        mIsLocalOnly = sharedPreferences.getBoolean("local_only", false);
    }


}


