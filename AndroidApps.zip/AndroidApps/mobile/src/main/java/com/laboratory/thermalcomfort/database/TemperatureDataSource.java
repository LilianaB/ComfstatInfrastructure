package com.laboratory.thermalcomfort.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import com.laboratory.thermalcomfort.models.Temperature;

import java.util.ArrayList;

/**
 * Created by Liliana Barrios on 08/03/16.
 */
public class TemperatureDataSource {

    private DBSqliteHelper mDBSqliteHelper;
    private static final String TAG = TemperatureDataSource.class.getSimpleName();

    public TemperatureDataSource(Context context) {
        mDBSqliteHelper = new DBSqliteHelper(context);
    }

    private SQLiteDatabase open() {
        return mDBSqliteHelper.getWritableDatabase();
    }

    private void close(SQLiteDatabase db) {
        db.close();
    }

    public ArrayList<Temperature> read() {
        SQLiteDatabase db = open();
        Cursor cursor = db.query(
                DBSqliteHelper.TEMPERATURE_TABLE,
                new String[]{BaseColumns._ID, DBSqliteHelper.COLUMN_TEMPERATURE_DEGREES,
                        DBSqliteHelper.COLUMN_TEMPERATURE_CREATION_DATE, DBSqliteHelper.COLUMN_TEMPERATURE_SYNC},
                null, //selection
                null, //selection args
                null, //group by
                null, //having
                null); //order

        ArrayList<Temperature> temperatureRecords = new ArrayList<Temperature>();
        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                Temperature temperature = new Temperature(getIntFromColumnName(cursor, BaseColumns._ID),
                        getFloatFromColumnName(cursor, DBSqliteHelper.COLUMN_TEMPERATURE_DEGREES),
                        getLongFromColumnName(cursor, DBSqliteHelper.COLUMN_TEMPERATURE_CREATION_DATE),
                        getIntFromColumnName(cursor, DBSqliteHelper.COLUMN_TEMPERATURE_SYNC)
                );
                temperatureRecords.add(temperature);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();
        db.close();
        return temperatureRecords;
    }

    public  Cursor getCursor() {

        SQLiteDatabase db = open();

        String whereClause = DBSqliteHelper.COLUMN_TEMPERATURE_SYNC + "=?";

        Cursor cursor = db.query(
                DBSqliteHelper.TEMPERATURE_TABLE,
                new String[]{BaseColumns._ID, DBSqliteHelper.COLUMN_TEMPERATURE_DEGREES,
                        DBSqliteHelper.COLUMN_TEMPERATURE_CREATION_DATE , DBSqliteHelper.COLUMN_TEMPERATURE_SYNC},
                whereClause,
                new String[] {String.valueOf(0)},
                null, //group by
                null, //having
                null); //order
        //db.close();
        return cursor;
    }

    public void update(Cursor cursor) {
        Log.d(TAG, "Updating Records");

        SQLiteDatabase db = open();
        db.beginTransaction();

        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                int recordId = getIntFromColumnName(cursor, BaseColumns._ID);
                ContentValues cv = new ContentValues();
                cv.put(DBSqliteHelper.COLUMN_TEMPERATURE_SYNC,1);
                db.update(DBSqliteHelper.TEMPERATURE_TABLE,
                        cv,
                        "_id="+recordId,
                        null);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();

        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

    public void create(Temperature temperature) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        ContentValues temperatureValues = new ContentValues();
        temperatureValues.put(DBSqliteHelper.COLUMN_TEMPERATURE_DEGREES, temperature.getDegrees());
        temperatureValues.put(DBSqliteHelper.COLUMN_TEMPERATURE_CREATION_DATE, temperature.getCreationDate());
        temperatureValues.put(DBSqliteHelper.COLUMN_TEMPERATURE_SYNC, 0);
        long memeID = db.insert(DBSqliteHelper.TEMPERATURE_TABLE, null, temperatureValues);

        db.setTransactionSuccessful();
        db.endTransaction();
        close(db);

    }

    private int getIntFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getInt(columnIndex);
    }

    private String getStringFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getString(columnIndex);

    }
    private Float getFloatFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getFloat(columnIndex);
    }

    private Long getLongFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getLong(columnIndex);
    }

    public void delete(int temperatureId) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        //String format is the where clause of the query
        db.delete(DBSqliteHelper.TEMPERATURE_TABLE,
                String.format("%s=%s", BaseColumns._ID,
                        String.valueOf(temperatureId)),
                null);
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

}
