package com.laboratory.thermalcomfort;

import android.content.Context;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.wearable.MessageApi;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.Wearable;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.SessionUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.laboratory.thermalcomfort.utils.Constants.*;

public class HeartRateActivity extends Activity implements
        MessageApi.MessageListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {


    @Bind(R.id.heartRateTextView) TextView mHeartRateTextView;
    @Bind(R.id.batteryTextView) TextView mBatteryTextView;
    @Bind(R.id.progressBar) ProgressBar mProgressBar;
    @Bind(R.id.refreshImageView) ImageView mRefresh;

    /**
     * Request code for launching the Intent to resolve Google Play services errors.
     */
    private static final int REQUEST_RESOLVE_ERROR = 1000;
    private static final String TAG = HeartRateActivity.class.getSimpleName();

    private GoogleApiClient mGoogleApiClient;
    private boolean mResolvingError = false;
    private String mHeartRate;
    private String mBattery;
    private String mElapsedTime;
    private String mAccuracy;
    public String msg = "Message from Mobile with DataLayer";
    private String mRaspberryPiUrl;
    protected Activity mSelf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate);
        ButterKnife.bind(this);

        mProgressBar.setVisibility(View.INVISIBLE);

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Wearable.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();

        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
        mSelf = this;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!mResolvingError) {
            mGoogleApiClient.connect();

            Log.d(TAG, "Generating RPC: heart-rate service");
            // Trigger an AsyncTask that will query for a list of connected nodes and send a
            // "start-activity" message to each connected node.
            toggleRefresh();
            new StartWearableActivityTask().execute();
        }
    }

    @Override
    protected void onStop() {
        if (!mResolvingError) {
            Wearable.MessageApi.removeListener(mGoogleApiClient, this);
            mGoogleApiClient.disconnect();
        }
        super.onStop();
    }

    @Override //ConnectionCallbacks
    public void onConnected(Bundle connectionHint) {
        Log.d(TAG, "Google API Client was connected");
        mResolvingError = false;
        //mStartActivityBtn.setEnabled(true);
        Wearable.MessageApi.addListener(mGoogleApiClient, this);
    }

    @Override //ConnectionCallbacks
    public void onConnectionSuspended(int cause) {
        Log.d(TAG, "Connection to Google API client was suspended");
        //mStartActivityBtn.setEnabled(false);
    }

    @Override //OnConnectionFailedListener
    public void onConnectionFailed(ConnectionResult result) {
        toggleRefresh();
        if (mResolvingError) {
            // Already attempting to resolve an error.
            return;
        } else if (result.hasResolution()) {
            try {
                mResolvingError = true;
                result.startResolutionForResult(this, REQUEST_RESOLVE_ERROR);
            } catch (IntentSender.SendIntentException e) {
                // There was an error with the resolution intent. Try again.
                mGoogleApiClient.connect();
            }
        } else {
            Log.e(TAG, "Connection to Google API client has failed");
            mResolvingError = false;
            Wearable.MessageApi.removeListener(mGoogleApiClient, this);
            NetworkUtil.alertUserAboutError(this);
        }
    }

    @Override //MessageListener
    public void onMessageReceived(final MessageEvent messageEvent) {
        Log.d(TAG, messageEvent.getPath().toString());
        String path = messageEvent.getPath().toString();
        final String message = new String(messageEvent.getData());
        processMessage(message);
        if (path.compareTo(START_ACTIVITY_PATH) == 0) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "triggered from activity");
                    toggleRefresh();

                    Log.d(TAG, "onMessageReceived() A message from watch was received:" + messageEvent
                            .getRequestId() + " " + messageEvent.getPath() + " " + message);
                    mHeartRateTextView.setText(mHeartRate);
                    mBatteryTextView.setText(mBattery);
                    //Toast.makeText(getApplicationContext(), "HeartRate " + mHeartRate + " Battery " + mBattery, Toast.LENGTH_LONG).show();
                }
            });

            if (NetworkUtil.isNetworkAvailable(this)) {
                OkHttpClient client = new OkHttpClient();
                String raspberryURL = buildURL();


                JSONObject jsonData = new JSONObject();

                try {
                    jsonData.put(HEART_RATE, mHeartRate);
                    jsonData.put(CREATION_TIME, TimeUtil.currentTime());
                    jsonData.put(BATTERY, mBattery);
                    jsonData.put(USER_ID, SessionUtil.getCurrentUserId(getApplicationContext()));
                    jsonData.put(ELAPSED_TIME, mElapsedTime);
                    jsonData.put(ACCURACY, mAccuracy);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
                Request request = new Request.Builder()
                        .url(raspberryURL)
                        .addHeader("Content-Type", "text/json; Charset=UTF-8")
                        .post(body)
                        .build();

                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(Request request, IOException e) {
                        Log.e(TAG, "Failed to connect to server " + e.getMessage());
                    }

                    @Override
                    public void onResponse(Response response) throws IOException {

                        try {
                            String jsonWeatherData = response.body().string();
                            Log.v(TAG, jsonWeatherData);
                            if (response.isSuccessful()) {
                                //do something
                                Log.d(TAG, "Created heart rate record on server");
                            } else {
                                Log.e(TAG, "Response unsuccessful");
                            }
                        } catch (IOException e) {
                            Log.e(TAG, "Exception caught:", e);
                        }
                    }
                });
            } else {
                Toast.makeText(this, getString(R.string.network_unavailable_message),
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void processMessage(String message) {
        String[] separated = message.split(TOKEN);
        mHeartRate = separated[0];
        mBattery = separated[1];
        mElapsedTime = separated[2];
        mAccuracy = separated[3];
        Log.d(TAG, "Message " + mHeartRate + " "+ mBattery + " "+ mElapsedTime + " "+mAccuracy);
    }

    private Collection<String> getNodes() {
        HashSet<String> results = new HashSet<>();
        NodeApi.GetConnectedNodesResult nodes =
                Wearable.NodeApi.getConnectedNodes(mGoogleApiClient).await();

        List<Node> connectedNodes = nodes.getNodes();
        if (connectedNodes.size() == 0) {

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.e(TAG, "No nodes connected");
                    toggleRefresh();
                    NetworkUtil.alertUserAboutError(mSelf);
                }
            });

        }
        for (Node node :connectedNodes ) {
            results.add(node.getId());
        }

        return results;
    }

    private void sendStartHeartRateServiceMessage(String node) {
        Wearable.MessageApi.sendMessage(
                mGoogleApiClient, node, START_ACTIVITY_PATH, msg.getBytes()).setResultCallback(
                new ResultCallback<MessageApi.SendMessageResult>() {
                    @Override
                    public void onResult(MessageApi.SendMessageResult sendMessageResult) {
                        if (!sendMessageResult.getStatus().isSuccess()) {
                            Log.e(TAG, "Failed to send message with status code: "
                                    + sendMessageResult.getStatus().getStatusCode());
                        } else {
                            Log.d(TAG, "SUCCESS");
                        }
                    }
                }
        );
    }

    private class StartWearableActivityTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... args) {
            Collection<String> nodes = getNodes();
            for (String node : nodes) {
                sendStartHeartRateServiceMessage(node);
            }
            return null;
        }
    }

    @OnClick(R.id.refreshImageView)
    public void refreshDisplay() {
        toggleRefresh();
        new StartWearableActivityTask().execute();
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/environment";
    }

    private void toggleRefresh() {
        if (mProgressBar.getVisibility() == View.INVISIBLE) {
            mProgressBar.setVisibility(View.VISIBLE);
            mRefresh.setVisibility(View.INVISIBLE);
        }else {
            mProgressBar.setVisibility(View.INVISIBLE);
            mRefresh.setVisibility(View.VISIBLE);
        }
    }



}
