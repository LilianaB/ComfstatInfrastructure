package com.laboratory.thermalcomfort.models;

/**
 * Created by Liliana Barrios on 22/02/16.
 */
public class Polar {

    private int mId;
    private int mHeartRate;
    private String mRRInterval;
    private long mCreationDate;
    private int mSync;

    public Polar(int id, int heartRate, String RRInterval, long creationDate, int sync) {
        mId = id;
        mHeartRate = heartRate;
        mRRInterval = RRInterval;
        mCreationDate = creationDate;
        mSync = sync;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public int getHeartRate() {
        return mHeartRate;
    }

    public void setHeartRate(int heartRate) {
        mHeartRate = heartRate;
    }

    public String getRRInterval() {
        return mRRInterval;
    }

    public void setRRInterval(String RRInterval) {
        mRRInterval = RRInterval;
    }

    public long getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(long creationDate) {
        mCreationDate = creationDate;
    }

    public int getSync() {
        return mSync;
    }

    public void setSync(int sync) {
        mSync = sync;
    }
}
