package com.laboratory.thermalcomfort;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceScreen;
import android.preference.SwitchPreference;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.laboratory.thermalcomfort.alarm.NotificationAlarmReceiver;
import com.laboratory.thermalcomfort.alarm.HeartRateAlarmReceiver;
import com.laboratory.thermalcomfort.location.WifiAlarmReceiver;

/**
 * Created by Liliana Barrios on 09/10/15.
 */
public class PreferenceFragment extends android.preference.PreferenceFragment {

    static final String TAG = PreferenceFragment.class.getSimpleName();
    static final NotificationAlarmReceiver M_NOTIFICATION_ALARM_RECEIVER = new NotificationAlarmReceiver();
    static final HeartRateAlarmReceiver mHRAlarmReceiver = new HeartRateAlarmReceiver();
    static final WifiAlarmReceiver mWifiAlarmReceiver = new WifiAlarmReceiver();
    private static final int REQUEST_CODE_ASK_PERMISSIONS = 123; //application specific

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preference);


        final ListPreference frequencyListPreference = (ListPreference)findPreference("frequency");
        frequencyListPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {

                String tag = newValue.toString();
                Log.d(TAG, tag);
                M_NOTIFICATION_ALARM_RECEIVER.setAlarm(getActivity(), tag);
                return true;
            }
        });

        final ListPreference frequencyHRListPreference = (ListPreference)findPreference("heart");
        frequencyHRListPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {

                String tag = newValue.toString();
                Log.d(TAG, tag);
                mHRAlarmReceiver.setAlarm(getActivity(), tag);
                return true;
            }
        });

        SwitchPreference locationSwitchPreference = (SwitchPreference)findPreference("pref_key_location");
        locationSwitchPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {

                boolean state = (Boolean) newValue;
                if (state) {
                    mWifiAlarmReceiver.setAlarm(getContext());
                } else {
                    mWifiAlarmReceiver.cancelAlarm(getContext());
                }

                return true;
            }
        });

        int hasLocationPermission = getActivity().checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (hasLocationPermission != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_CODE_ASK_PERMISSIONS);
            return;
        } else {
            Log.d(TAG, "Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission Granted
                    Log.d(TAG, "permission granted");
                } else {
                    // Permission Denied
                    Toast.makeText(getActivity(), "ACCESS_COARSE_LOCATION Denied", Toast.LENGTH_SHORT)
                            .show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    @Override
    public void onStart() {
        super.onStart();

        //update heart rate monitor summaries
        SharedPreferences sharedPref = getActivity().getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        boolean deviceAlreadyConnected = sharedPref.getBoolean(getString(R.string.pref_bluetooth_device_state), false);
        smartwatchSummaryUpdate(getString(R.string.key_prefs_smartwatchStatus), getString(R.string.key_prefs_smartwatch));
        monitorSummaryUpdate(getString(R.string.key_prefs_polar), deviceAlreadyConnected);

        boolean arduinoAlreadyConnected = sharedPref.getBoolean(getString(R.string.pref_arduino_bluetooth_state), false);
        monitorSummaryUpdate("arduino", arduinoAlreadyConnected);
    }

    private void monitorSummaryUpdate(String name, boolean state) {
        final PreferenceScreen monitorPreferenceScreen = (PreferenceScreen) findPreference(name);
        monitorPreferenceScreen.setSummary(state ? getString(R.string.on) : getString(R.string.off));
        ((BaseAdapter) getPreferenceScreen().getRootAdapter()).notifyDataSetChanged();
    }

    //takes care of updating monitor status on main settings screen
    private void smartwatchSummaryUpdate(String switchPref, String prefScreen ) {

        SwitchPreference switchStatusPreference = (SwitchPreference)findPreference(switchPref);
        final PreferenceScreen monitorPreferenceScreen = (PreferenceScreen) findPreference(prefScreen);

        boolean isChecked = switchStatusPreference.isChecked();
        monitorPreferenceScreen.setSummary(isChecked ? getString(R.string.on) : getString(R.string.off));
        switchStatusPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                boolean newValueBool = (Boolean) newValue;
                monitorPreferenceScreen.setSummary(newValueBool ? getString(R.string.on) : getString(R.string.off));
                ((BaseAdapter) getPreferenceScreen().getRootAdapter()).notifyDataSetChanged();
                return true; // in case you want to disallow the change return false
            }
        });
    }

}
