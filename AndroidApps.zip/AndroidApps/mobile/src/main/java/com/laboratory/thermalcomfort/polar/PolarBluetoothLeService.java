
package com.laboratory.thermalcomfort.polar;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.database.PolarDataSource;
import com.laboratory.thermalcomfort.models.Polar;
import com.laboratory.thermalcomfort.utils.Constants;
import com.laboratory.thermalcomfort.utils.TimeUtil;

import org.acra.ACRA;

import static com.laboratory.thermalcomfort.polar.PolarFilters.*;
import static com.laboratory.thermalcomfort.utils.Constants.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;


/**
 * Service for managing connection and data communication with a GATT server hosted on a
 * given Bluetooth LE device.
 */
// A service that interacts with the BLE device via the Android BLE API.
public class PolarBluetoothLeService extends Service {

    private final static String TAG = PolarBluetoothLeService.class.getSimpleName();

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    private int mConnectionState = BLE_ACTIVITY_CONNECTION_FAILED;


    private Messenger messageHandler;
    private boolean mConnected = false;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private boolean requestFromActivity;

    static final PolarAlarmReceiver mPolarAlarmReceiver = new PolarAlarmReceiver();

    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change and services discovered.
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                intentAction = ACTION_GATT_CONNECTED;
                mConnectionState = BLE_NO_SENSOR;
                broadcastUpdate(intentAction);
                Log.i(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Log.i(TAG, "Attempting to start service discovery:" +
                        mBluetoothGatt.discoverServices());

                //setRepeatingAlarm
                mPolarAlarmReceiver.setAlarm(getApplicationContext());

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                intentAction = ACTION_GATT_DISCONNECTED;
                mConnectionState = BLE_ACTIVITY_CONNECTION_FAILED;
                Log.i(TAG, "Disconnected from GATT server.");
                broadcastUpdate(intentAction);
                mPolarAlarmReceiver.cancelAlarm(getApplicationContext());
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.w(TAG, "onServicesDiscovered success: " + status);
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }
    };

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);

    }

    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);

        // This is special handling for the Heart Rate Measurement profile.  Data parsing is
        // carried out as per profile specifications:
        // http://developer.bluetooth.org/gatt/characteristics/Pages/CharacteristicViewer.aspx?u=org.bluetooth.characteristic.heart_rate_measurement.xml
        if (UUID_HEART_RATE_MEASUREMENT.equals(characteristic.getUuid())) {
            int flag = characteristic.getProperties();
            int format = -1;

            //00000001
            if ((flag & 0x01) != 0) {
                format = BluetoothGattCharacteristic.FORMAT_UINT16;
                Log.d(TAG, "Heart rate format UINT16.");
            } else {
                format = BluetoothGattCharacteristic.FORMAT_UINT8;
                Log.d(TAG, "Heart rate format UINT8.");
            }
            final int heartRate = characteristic.getIntValue(format, 1);
            Log.d(TAG, String.format("Received heart rate: %d", heartRate));

            byte[] bytes = characteristic.getValue();
            if ((flag & 0x10) != 0) {
                // RR stuff.
                ArrayList<Integer> rrValues = new ArrayList<Integer>();
                for (int i=2;i<bytes.length;i+=2){
                    int rr = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT16, i);
                    if ((rrValues.size() > 0)&&(rrValues.get(rrValues.size()-1) == rr)) {
                        //Log.i(TAG, "Multiple RR values identical - ignoring identical values");
                    } else {
                        rrValues.add(rr);
                    }
                }
                intent.putIntegerArrayListExtra(RR_DATA, rrValues);
            }

            intent.putExtra(EXTRA_DATA, String.valueOf(heartRate));
        } else {
            // For all other profiles, writes the data formatted in HEX.
            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0) {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for(byte byteChar : data)
                    stringBuilder.append(String.format("%02X ", byteChar));
                intent.putExtra(EXTRA_DATA, new String(data) + "\n" + stringBuilder.toString());
            }
        }
        sendBroadcast(intent);
    }


    public class LocalBinder extends Binder {
        PolarBluetoothLeService getService() {
            return PolarBluetoothLeService.this;
        }
    }

    @Override
    public int onStartCommand (Intent intent, int flags, int startId) {
        super.onCreate();
        String mDeviceAddress;

        if (intent != null) {

            requestFromActivity = true;
            mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);
            messageHandler = (Messenger) intent.getParcelableExtra("MESSENGER");
            Log.d(TAG, "OnStartCommand with intent " + mDeviceAddress);

        } else {

            requestFromActivity = false;
            SharedPreferences sharedPref = getSharedPreferences(
                    "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
            mDeviceAddress = sharedPref.getString(getString(R.string.pref_current_bluetooth_device_address), "");
            Log.d(TAG, "OnStartCommand without intent " + mDeviceAddress);

        }


        if(initialize()) {
            connect(mDeviceAddress);
            registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        }

        //return sticky to startservice automatically after failure
        return START_STICKY;
    }


    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }

    private final IBinder mBinder = new LocalBinder();

    /**
     * Initializes a reference to the local Bluetooth adapter.
     *
     * @return Return true if the initialization is successful.
     */
    public boolean initialize() {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     *
     * @param address The device address of the destination device.
     *
     * @return Return true if the connection is initiated successfully. The connection result
     *         is reported asynchronously through the
     *         {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     *         callback.
     */
    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        // Previously connected device.  Try to reconnect.
        if (mBluetoothDeviceAddress != null && address.equals(mBluetoothDeviceAddress)
                && mBluetoothGatt != null) {
            Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
            if (mBluetoothGatt.connect()) {
                mConnectionState = BLE_ACTIVITY_CONNECTED;

                return true;
            } else {
                return false;
            }
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        if (device == null) {
            Log.w(TAG, "Device not found.  Unable to connect.");
            return false;
        }
        // We want to  auto-connect the device, so we are setting the autoConnect
        // parameter to true
        mBluetoothGatt = device.connectGatt(this, true, mGattCallback);
        Log.d(TAG, "Trying to create a new connection.");
        mBluetoothDeviceAddress = address;
        mConnectionState = BLE_ACTIVITY_CONNECTED;

        return true;
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(mGattUpdateReceiver);
        close();
        mPolarAlarmReceiver.cancelAlarm(getApplicationContext());
        super.onDestroy();
    }


    /**
     * Disconnects an existing connection or cancel a pending connection. The disconnection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.disconnect();
    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    /**
     * Request a read on a given {@code BluetoothGattCharacteristic}. The read result is reported
     * asynchronously through the {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
     * callback.
     *
     * @param characteristic The characteristic to read from.
     */
    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        Log.d(TAG, "read characteristic");
        mBluetoothGatt.readCharacteristic(characteristic);
    }

    /**
     * Enables or disables notification on a give characteristic.
     *
     * @param characteristic Characteristic to act on.
     * @param enabled If true, enable notification.  False otherwise.
     */
    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);

        // This is specific to Heart Rate Measurement.
        if (UUID_HEART_RATE_MEASUREMENT.equals(characteristic.getUuid())) {
            Log.d(TAG, "Specific HR notification");
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(
                    UUID.fromString(HeartRateGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            mBluetoothGatt.writeDescriptor(descriptor);
        }
    }

    /**
     * Retrieves a list of supported GATT services on the connected device. This should be
     * invoked only after {@code BluetoothGatt#discoverServices()} completes successfully.
     *
     * @return A {@code List} of supported services.
     */
    public List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;

        return mBluetoothGatt.getServices();
    }

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (ACTION_GATT_CONNECTED.equals(action)) {
                Log.d(TAG, "GATT receiver connected");
                mConnected = true;
                if(requestFromActivity) {
                    sendMessage(Constants.BLE_ACTIVITY_CONNECTED);
                }
                updateConnectionGlobalStatus(true);
            } else if (ACTION_GATT_DISCONNECTED.equals(action)) {
                Log.d(TAG, "GATT receiver disconnected");
                if(requestFromActivity) {
                    sendMessage(Constants.BLE_ACTIVITY_CONNECTION_FAILED);
                }
                updateConnectionGlobalStatus(false);

                ACRA.getErrorReporter().handleException(new PolarException("Disconnect", getApplicationContext()));


            } else if (ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                Log.d(TAG, "GATT receiver discover services");
                // Show all the supported services and characteristics on the user interface.
                displayGattServices(getSupportedGattServices());
            } else if (ACTION_DATA_AVAILABLE.equals(action)) {

                int hr = Integer.parseInt(intent.getStringExtra(EXTRA_DATA));
                String rrInterval = intent.getIntegerArrayListExtra(RR_DATA).toString();

                Polar polarRecord = new Polar(-1, hr, rrInterval, TimeUtil.currentTime(), 0);
                Log.d(TAG, "HR " +  hr + " "+ rrInterval);

                createDBRecord(polarRecord);
            }
        }
    };

    private void createDBRecord (Polar polar) {
        PolarDataSource polarDataSource = new PolarDataSource(this);
        polarDataSource.create(polar);
    }


    // Iterate through the supported GATT Services/Characteristics and select HR measurement
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        String uuid = null;
        boolean hasHRService = false;

        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();

            if (uuid.equals(HeartRateGattAttributes.HEART_RATE_SERVICE)) {

                List<BluetoothGattCharacteristic> gattCharacteristics =
                        gattService.getCharacteristics();

                BluetoothGattCharacteristic bluetoothGattHRCharacteristic =
                        getHeartRateMeasurementCharacteristic(gattCharacteristics);

                if (bluetoothGattHRCharacteristic != null){
                    enableNotifications( bluetoothGattHRCharacteristic);
                    hasHRService = true;
                } else {
                    Log.d(TAG, "No HR Characteristic detected");
                }
            }
        }

        if (!hasHRService) {
            Log.d(TAG, "HR Service unavailable");
            if (mConnected) {
                close();
                updateConnectionGlobalStatus(false);
                if (requestFromActivity) {
                    sendMessage(Constants.BLE_NO_SENSOR);
                }
                mConnected = false;
            }
        }
    }

    private BluetoothGattCharacteristic getHeartRateMeasurementCharacteristic( List<BluetoothGattCharacteristic> gattCharacteristics ) {
        // Loops through available Characteristics.
        for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
            HashMap<String, String> currentCharaData = new HashMap<String, String>();
            String uuid = gattCharacteristic.getUuid().toString();

            if (uuid.equals(HeartRateGattAttributes.HEART_RATE_MEASUREMENT)) {
                Log.d(TAG, "Heart rate measurement characteristic detected");
                return gattCharacteristic;
            }
        }
        return null;
    }

    private boolean enableNotifications( BluetoothGattCharacteristic characteristic) {
        final int charaProp = characteristic.getProperties();
        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
            // If there is an active notification on a characteristic, clear
            // it first so it doesn't update the data field on the user interface.
            if (mNotifyCharacteristic != null) {
                setCharacteristicNotification(
                        mNotifyCharacteristic, false);
                mNotifyCharacteristic = null;
            }
            readCharacteristic(characteristic);
        }
        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            mNotifyCharacteristic = characteristic;
            setCharacteristicNotification(
                    characteristic, true);
        }
        return true;
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_GATT_CONNECTED);
        intentFilter.addAction(ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(ACTION_DATA_AVAILABLE);
        return intentFilter;
    }

    public void sendMessage(int state) {
        Message message = Message.obtain();
        switch (state) {
            case Constants.BLE_ACTIVITY_CONNECTED:
                message.arg1 = Constants.BLE_ACTIVITY_CONNECTED;
                break;
            case Constants.BLE_ACTIVITY_CONNECTION_FAILED:
                message.arg1 = Constants.BLE_ACTIVITY_CONNECTION_FAILED;
                break;
            case Constants.BLE_NO_SENSOR:
                message.arg1 = Constants.BLE_NO_SENSOR;
        }
        try {
            messageHandler.send(message);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private void updateConnectionGlobalStatus(boolean connected) {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(getString(R.string.pref_bluetooth_device_state), connected);
        editor.commit();

    }
}
