package com.laboratory.thermalcomfort.adapters;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.models.Comfort;
import com.laboratory.thermalcomfort.models.ThermalComfort;
import com.laboratory.thermalcomfort.utils.TimeUtil;

/**
 * Created by Liliana Barrios on 22/11/15.
 */
public class ComfortAdapter  extends BaseAdapter {

    private static final String TAG = ComfortAdapter.class.getSimpleName();

    private Context mContext;
    private Comfort mComforts[];

    public ComfortAdapter(Context context, Comfort comforts[]) {
        mContext = context;
        mComforts = comforts;

    }
    @Override
    public int getCount() {
        return mComforts.length;
    }

    @Override
    public Object getItem(int position) {
        return mComforts[position];
    }

    @Override
    public long getItemId(int position) {
        return 0; //can be use to tag for references
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.comfort_level_list_item, null);
            holder = new ViewHolder();
            holder.timeTextView = (TextView)convertView.findViewById(R.id.timeTextView);
            holder.ashraeTextView = (TextView)convertView.findViewById(R.id.ashreaLabel);
            holder.iconImageView = (ImageView) convertView.findViewById(R.id.iconImageView);
            holder.usernameTextView = (TextView) convertView.findViewById(R.id.usernameTextView);
            holder.tmpTextView = (TextView) convertView.findViewById(R.id.temperatureTextView);
            holder.avatarImageView = (ImageView) convertView.findViewById(R.id.avatarImageView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder)convertView.getTag();
        }

        Comfort comfort = mComforts[position];
        int comfortValue = comfort.getComfortValue();
        String comfortLevel = ThermalComfort.getAshraeString(comfortValue);
        holder.iconImageView.setImageResource(ThermalComfort.getIconId(comfortLevel));
        holder.ashraeTextView.setText(comfortLevel);
        holder.timeTextView.setText("At " + comfort.getCreationDate());
        holder.usernameTextView.setText(comfort.getUsername());
        holder.tmpTextView.setText(comfort.getTemperature() +""+ (char) 0x00B0 );

        String result = String.format("ic_avatar_%s", comfort.getUserId());
        int picId = mContext.getResources().getIdentifier(result, "mipmap", mContext.getPackageName());
        holder.avatarImageView.setImageResource(picId);
        convertView.setBackgroundColor(Color.parseColor(ThermalComfort.getColor(comfortLevel)));
        return convertView;
    }

    private static class ViewHolder {
        ImageView iconImageView;
        TextView ashraeTextView;
        TextView timeTextView;
        TextView usernameTextView;
        TextView tmpTextView;
        ImageView avatarImageView;
    }
}