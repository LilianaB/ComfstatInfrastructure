package com.laboratory.thermalcomfort.polar;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.database.PolarDataSource;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.acra.ACRA;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static com.laboratory.thermalcomfort.utils.Constants.POLAR_VALUES;
import static com.laboratory.thermalcomfort.utils.Constants.USER_ID;

/**
 * Created by Liliana Barrios on 22/02/16.
 */
public class PolarSchedulingService extends IntentService {

    private static final String TAG = PolarSchedulingService.class.getSimpleName();
    private String mRaspberryPiUrl;
    PolarDataSource mPolarDataSource;
    Cursor mPolarCursor;


    public PolarSchedulingService() {
        super("PolarSchedulingService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);

        //todo trigger connection with server, query db
        Log.d(TAG, "QUERY + SERVER");
        mPolarDataSource = new PolarDataSource(getApplicationContext());
        mPolarCursor = mPolarDataSource.getCursor();
        JSONArray polarJson = getUnsyncedResults(mPolarCursor);

        Log.d(TAG, polarJson.toString());

        sendPolarHRToServer(polarJson);

    }

    private void sendPolarHRToServer(JSONArray polarJson ) {
        if (NetworkUtil.isNetworkAvailable(this)) {
            OkHttpClient client = new OkHttpClient();
            client.setConnectTimeout(200, TimeUnit.SECONDS);
            client.setReadTimeout(200, TimeUnit.SECONDS);
            client.setWriteTimeout(200, TimeUnit.SECONDS);
            String raspberryURL = buildURL();

            JSONObject jsonData = new JSONObject();

            try {
                jsonData.put(USER_ID, getCurrentUserId());
                jsonData.put(POLAR_VALUES, polarJson);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .addHeader("Content-Type", "text/json; Charset=UTF-8")
                    .post(body)
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    //todo check if error here is due timeout
                    Log.e(TAG, getString(R.string.server_connection_failed) + e.getMessage());
                    ACRA.getErrorReporter().handleException(new PolarException("Polar timeout", getApplicationContext()));
                    //todo close cursor
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, getString(R.string.server_message_sent));
                        //todo set all records as sync
                        mPolarDataSource.update(mPolarCursor);

                    } else {
                        Log.e(TAG, getString(R.string.server_response_failed));
                        ACRA.getErrorReporter().handleException(new PolarException(getString(R.string.server_response_failed), getApplicationContext()));
                    }
                }
            });
        } else {
            Toast.makeText(this, getString(R.string.network_unavailable_message),
                    Toast.LENGTH_LONG).show();
        }
    }

    private JSONArray getUnsyncedResults(Cursor cursor) {

        JSONArray resultSet     = new JSONArray();
        cursor.moveToFirst();

        while (cursor.isAfterLast() == false) {

            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for( int i=0 ;  i< totalColumn ; i++ )  {
                if( cursor.getColumnName(i) != null ) {
                    try {
                        if( cursor.getString(i) != null ) {
                          //  Log.d("TAG_NAME", cursor.getString(i));

                            String columnName = cursor.getColumnName(i);
                            if (columnName.equals("creationDate")){
                                rowObject.put( columnName, cursor.getLong(i));
                            }
                            else if (columnName.equals("rrInterval")){
                                rowObject.put( columnName, cursor.getString(i));
                            } else {
                                rowObject.put( columnName, cursor.getInt(i));
                            }
                        }
                        else {
                            rowObject.put( cursor.getColumnName(i) ,  "" );
                        }
                    }
                    catch( Exception e ) {
                        Log.d("TAG_NAME", e.getMessage()  );
                    }
                }
            }
            resultSet.put(rowObject);
            cursor.moveToNext();
        }
        //cursor.close();
        //Log.d("TAG_NAME", resultSet.toString() );
        return resultSet;
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/polar";
    }

    private int getCurrentUserId() {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        return sharedPref.getInt(getString(R.string.pref_current_user_id), 0);
    }

}
