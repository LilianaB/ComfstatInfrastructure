package com.laboratory.thermalcomfort.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Liliana Barrios on 01/10/15.
 */
public class TimeUtil {

    public static long currentTime() {
        return System.currentTimeMillis() / 1000L;
    }

    public static String changeDateFormat(String dateStr) {
        DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.GERMANY);
        DateFormat targetFormat = new SimpleDateFormat("HH:mm");
        Date date = null;
        try {
            date = originalFormat.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String formattedDate = targetFormat.format(date);  // 20120821

        return formattedDate.toString();
    }

    public static String getFormattedDate() {
        long yourmilliseconds = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        Date resultdate = new Date(yourmilliseconds);
        String date = sdf.format(resultdate);
        return date;
    }
}