package com.laboratory.thermalcomfort.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.preference.PreferenceManager;
import android.util.Log;

import com.laboratory.thermalcomfort.AlertDialogFragment;
import com.squareup.okhttp.MediaType;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * Created by Liliana Barrios on 12/11/15.
 */
public class NetworkUtil {

    private static final String TAG = NetworkUtil.class.getSimpleName();
    private static final int WIFI_STRENGTH_LEVELS = 5;
    private static final int WIFI_QUEUE_SIZE = 10;
    static WifiManager mWifiManager;

    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager manager = (ConnectivityManager)
                 context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;

       // if (networkInfo != null && networkInfo.isConnected() && isConnectedToDesiredWifi(context)) {
        if (networkInfo != null && networkInfo.isConnected()) {
            isAvailable = true;
        }

        return isAvailable;
    }

    public static String getUserPreferences(Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString("raspberry", "place here comfstat server address"); //
    }

    public static void alertUserAboutError(Activity activity) {
        AlertDialogFragment dialog = new AlertDialogFragment();
        dialog.show(activity.getFragmentManager(), "error_dialog");
    }

    /** Detect you are connected to a specific network. */
    public static boolean isConnectedToDesiredWifi(Context context) {

        boolean connected = false;

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String desiredMacAddress = sharedPreferences.getString("wifi", "insert router mac address");

        WifiManager wifiManager =
                (WifiManager) context.getSystemService(Context.WIFI_SERVICE);

        WifiInfo wifi = wifiManager.getConnectionInfo();
        if (wifi != null) {
            // get current router Mac address
            String bssid = wifi.getBSSID();
            connected = desiredMacAddress.equals(bssid);
        }

        //return connected;
        return true;
    }

    public static String getCurrentWifiMacAddress(Context context) {

        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifi = wifiManager.getConnectionInfo();

        if (wifi != null) {
            return  wifi.getBSSID();// get current router Mac address
        }
        return null;
    }

    public String getCurrentAvailableWifis(Context context) {
        PriorityQueue<android.net.wifi.ScanResult> wifiQueue = wifiScan(context);
        StringBuilder macAddresses = new StringBuilder();

        while(!wifiQueue.isEmpty()) {
            android.net.wifi.ScanResult scanResult = wifiQueue.poll();
            macAddresses.append(scanResult.BSSID)
                    .append(", ");
        }

        return  macAddresses.toString();
    }

    public PriorityQueue<android.net.wifi.ScanResult> wifiScan(Context context) {

        mWifiManager =
                (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        List<android.net.wifi.ScanResult> wifiList = mWifiManager.getScanResults();
        PriorityQueue<android.net.wifi.ScanResult> wifiQueue = getStrongerSignal();

        for (int i = 0; i < wifiList.size(); i++){
            android.net.wifi.ScanResult scanResult = wifiList.get(i);
            Log.d(TAG, scanResult.SSID);
            if (wifiQueue.size() < WIFI_QUEUE_SIZE) {
                wifiQueue.add(scanResult);
            } else if (wifiQueue.size()>= WIFI_QUEUE_SIZE) {
                if (getSignalStrength(wifiQueue.peek()) < getSignalStrength(scanResult)) {
                    wifiQueue.poll();
                    wifiQueue.add(scanResult);
                }
            }
        }

        return wifiQueue;
    }

    private  PriorityQueue<android.net.wifi.ScanResult>  getStrongerSignal() {

        Comparator<android.net.wifi.ScanResult> comparator = new ScanResultComparator();
        PriorityQueue<android.net.wifi.ScanResult> strongerSignal =
                new PriorityQueue<android.net.wifi.ScanResult>(WIFI_QUEUE_SIZE, comparator);

        return  strongerSignal;
    }

    private int getSignalStrength(android.net.wifi.ScanResult scanResult)
    {
        return mWifiManager.calculateSignalLevel(scanResult.level, WIFI_STRENGTH_LEVELS);
    }

    class ScanResultComparator implements Comparator<android.net.wifi.ScanResult> {

        public int compare(android.net.wifi.ScanResult a, android.net.wifi.ScanResult b) {
            int aSignalStrength = mWifiManager.calculateSignalLevel(a.level, WIFI_STRENGTH_LEVELS);
            int bSignalStrength = mWifiManager.calculateSignalLevel(b.level, WIFI_STRENGTH_LEVELS);

            if (aSignalStrength < bSignalStrength) {
                return -1;
            } else if (aSignalStrength == bSignalStrength) {
                return 0;
            } else {
                return 1;
            }
        }
    }
}
