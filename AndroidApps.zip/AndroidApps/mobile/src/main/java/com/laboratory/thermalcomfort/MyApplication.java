package com.laboratory.thermalcomfort;

/**
 * Created by Liliana Barrios on 10/03/16.
 */

import android.content.Context;

import org.acra.*;
import org.acra.annotation.*;

@ReportsCrashes(
        mailTo = "liliana.usb@gmail.com",
        mode = ReportingInteractionMode.SILENT
)
public class MyApplication extends android.app.Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        // The following line triggers the initialization of ACRA
        ACRA.init(this);
    }
}
