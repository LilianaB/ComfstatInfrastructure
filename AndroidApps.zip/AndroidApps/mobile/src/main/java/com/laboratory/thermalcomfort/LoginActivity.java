package com.laboratory.thermalcomfort;

/**
 * Created by Liliana Barrios on 19/09/15.
 */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.SessionUtil;
import com.squareup.okhttp.Authenticator;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.Credentials;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.Proxy;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LoginActivity extends Activity {

    final static String TAG = LoginActivity.class.getSimpleName();

    @Bind(R.id.signinButton) Button mSignIn;
    @Bind(R.id.usernameEditText) EditText mUsername;
    @Bind(R.id.passwordEditText) EditText mPassword;
    @Bind(R.id.progressBar) ProgressBar mProgressBar;

    private String mRaspberryPiUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);

        getActionBar().hide();
        ButterKnife.bind(this);
        mProgressBar.setVisibility(View.INVISIBLE);
        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);

        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        boolean isLogged = sharedPref.getBoolean(getString(R.string.pref_is_user_logged), false);

        if (isLogged)
        {
            navegateToMain();
        }
    }

    @OnClick(R.id.signUpText)
    public void startSignUpActivity(View view) {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.signinButton)
    public void login() {
        final String username = mUsername.getText().toString();
        final String password = mPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
            builder.setMessage(R.string.login_error_message)
                    .setTitle(R.string.login_error_title)
                    .setPositiveButton(android.R.string.ok, null);
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {

            final OkHttpClient client = new OkHttpClient();
            String raspberryURL = buildURL();
            toggleRefresh();

            client.setAuthenticator(new Authenticator() {
                @Override
                public Request authenticate(Proxy proxy, Response response) {
                    String credential = Credentials.basic(username, password);
                    if (credential.equals(response.request().header("Authorization"))) {
                        return null; // If we already failed with these credentials, don't retry.
                    }
                    return response.request().newBuilder()
                            .header("Authorization", credential)
                            .build();
                }

                @Override
                public Request authenticateProxy(Proxy proxy, Response response) {
                    return null; // Null indicates no attempt to authenticate.
                }
            });

            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .build();

            Call call1 = client.newCall(request);
            call1.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    Log.d(TAG, "Failure");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toggleRefresh();
                        }
                    });
                    alertUserAboutError();
                    saveSessionValues(0, true);
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toggleRefresh();
                        }
                    });
                    if (response.isSuccessful()) {
                        Log.d(TAG, "Successful login");
                        String jsonData = response.body().string();
                        try {
                            JSONObject userData = new JSONObject(jsonData);
                            Log.d(TAG, "User id: " + userData.getInt("id"));
                            saveSessionValues(userData.getInt("id"), true);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.v(TAG, jsonData);
                        navegateToMain();
                    } else {
                        alertUserAboutError();
                        saveSessionValues(0, true);
                    }

                }
            });
        }
    }

    private void toggleRefresh() {
        if (mProgressBar.getVisibility() == View.INVISIBLE) {
            mProgressBar.setVisibility(View.VISIBLE);
        }else {
            mProgressBar.setVisibility(View.INVISIBLE);
        }
    }

    private void alertUserAboutError() {
        AlertDialogFragment dialog = new AlertDialogFragment();
        dialog.show(getFragmentManager(), "error_dialog");
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/user";
    }

    private void saveSessionValues(int id, boolean isLogged) {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.pref_current_user_id), id);
        editor.putBoolean(getString(R.string.pref_is_user_logged), isLogged);
        editor.commit();
    }

    private void navegateToMain() {

        SessionUtil sessionUtil = new SessionUtil();
        sessionUtil.startServices(this, TAG);

        Intent intent = new Intent(this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

}
