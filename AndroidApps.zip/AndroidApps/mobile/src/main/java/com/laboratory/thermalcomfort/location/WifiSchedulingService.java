package com.laboratory.thermalcomfort.location;

import android.app.IntentService;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.database.WifiDataSource;
import com.laboratory.thermalcomfort.models.Wifi;
import com.laboratory.thermalcomfort.polar.PolarException;
import com.laboratory.thermalcomfort.utils.JsonConverter;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.SessionUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.acra.ACRA;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static com.laboratory.thermalcomfort.utils.Constants.WIFI_VALUES;
import static com.laboratory.thermalcomfort.utils.Constants.USER_ID;

/**
 * Created by Liliana Barrios on 21/03/16.
 */
public class WifiSchedulingService extends IntentService {

    private static final String TAG = WifiSchedulingService.class.getSimpleName();
    private String mRaspberryPiUrl;
    Cursor mWifiCursor;
    WifiDataSource mWifiDataSource;


    public WifiSchedulingService() {
        super("WifiSchedulingService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
        mWifiDataSource = new WifiDataSource(getApplicationContext());
        queryWifisAvailable();
        mWifiCursor = mWifiDataSource.getCursor();
        Log.d(TAG, " ON HANDLE");
        JSONArray wifiJson = JsonConverter.getUnsyncedResults(mWifiCursor);

        Log.d(TAG, wifiJson.toString());
        sendWifiLocationToServer(wifiJson);

    }

    private void queryWifisAvailable() {

        NetworkUtil networkUtil = new NetworkUtil();
        String currentWifi =  networkUtil.getCurrentWifiMacAddress(getApplicationContext());
        String wifiList = networkUtil.getCurrentAvailableWifis(getApplicationContext());

        Wifi wifi = new Wifi(-1,currentWifi, wifiList,  TimeUtil.currentTime());
        mWifiDataSource.create(wifi);

    }
    private void sendWifiLocationToServer(JSONArray wifiJson) {
        if (NetworkUtil.isNetworkAvailable(this)) {
            OkHttpClient client = new OkHttpClient();
            client.setConnectTimeout(200, TimeUnit.SECONDS);
            client.setReadTimeout(200, TimeUnit.SECONDS);
            client.setWriteTimeout(200, TimeUnit.SECONDS);
            String raspberryURL = buildURL();

            JSONObject jsonData = new JSONObject();

            try {
                jsonData.put(USER_ID, SessionUtil.getCurrentUserId(getApplicationContext()));
                jsonData.put(WIFI_VALUES, wifiJson);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .addHeader("Content-Type", "text/json; Charset=UTF-8")
                    .post(body)
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    //todo check if error here is due timeout
                    Log.e(TAG, getString(R.string.server_connection_failed) + e.getMessage());
                    ACRA.getErrorReporter().handleException(new PolarException("Wifi timeout", getApplicationContext()));
                    //mWifiCursor.close();
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, getString(R.string.server_message_sent));
                        //todo set all records as sync
                        mWifiDataSource.update(mWifiCursor);

                    } else {
                        Log.e(TAG, getString(R.string.server_response_failed));
                        ACRA.getErrorReporter().handleException(new PolarException(getString(R.string.server_response_failed), getApplicationContext()));
                      //  mWifiCursor.close();
                    }
                }
            });
        } else {
            Toast.makeText(this, getString(R.string.network_unavailable_message),
                    Toast.LENGTH_LONG).show();
        }
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/location";
    }

}

