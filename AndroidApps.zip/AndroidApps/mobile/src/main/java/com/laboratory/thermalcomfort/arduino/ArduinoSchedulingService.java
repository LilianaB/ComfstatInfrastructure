package com.laboratory.thermalcomfort.arduino;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.database.BatteryDataSource;
import com.laboratory.thermalcomfort.database.HumidityDataSource;
import com.laboratory.thermalcomfort.database.TemperatureDataSource;
import com.laboratory.thermalcomfort.polar.PolarException;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.acra.ACRA;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static com.laboratory.thermalcomfort.utils.Constants.BATTERY_VALUES;
import static com.laboratory.thermalcomfort.utils.Constants.HUMIDITY_VALUES;
import static com.laboratory.thermalcomfort.utils.Constants.TEMPERATURE_VALUES;
import static com.laboratory.thermalcomfort.utils.Constants.USER_ID;

/**
 * Created by Liliana Barrios on 22/02/16.
 */
public class ArduinoSchedulingService extends IntentService {

    private static final String TAG = ArduinoSchedulingService.class.getSimpleName();
    private String mRaspberryPiUrl;
    TemperatureDataSource mTemperatureDataSource;
    HumidityDataSource mHumidityDataSource;
    BatteryDataSource mBatteryDataSource;
    Cursor mTemperatureCursor;
    Cursor mBatteryCursor;
    Cursor mHumidityCursor;


    public ArduinoSchedulingService() {
        super("ArduinoSchedulingService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);

        //todo trigger connection with server, query db
        Log.d(TAG, "Arduino QUERY + SERVER");
        mTemperatureDataSource = new TemperatureDataSource(getApplicationContext());
        mTemperatureCursor = mTemperatureDataSource.getCursor();

        mHumidityDataSource = new HumidityDataSource(getApplicationContext());
        mHumidityCursor = mHumidityDataSource.getCursor();

        mBatteryDataSource = new BatteryDataSource(getApplicationContext());
        mBatteryCursor = mBatteryDataSource.getCursor();

        JSONArray temperatureJson = getUnsyncedResults(mTemperatureCursor);
        JSONArray humidityJson = getUnsyncedResults(mHumidityCursor);
        JSONArray batteryJson = getUnsyncedResults(mBatteryCursor);

        Log.d(TAG , " TEMPERATURE" +  temperatureJson.toString());
        Log.d(TAG , " HUMIDITY" +  humidityJson.toString());
        Log.d(TAG , " BATTERY" +  batteryJson.toString());

        sendArduinoDataToServer(TEMPERATURE_VALUES, temperatureJson);
        sendArduinoDataToServer(HUMIDITY_VALUES, humidityJson);
        sendArduinoDataToServer(BATTERY_VALUES, batteryJson);
    }

    private void sendArduinoDataToServer(final String label, JSONArray recordsJson) {
        if (NetworkUtil.isNetworkAvailable(this)) {
            OkHttpClient client = new OkHttpClient();
            client.setConnectTimeout(200, TimeUnit.SECONDS);
            client.setReadTimeout(200, TimeUnit.SECONDS);
            client.setWriteTimeout(200, TimeUnit.SECONDS);
            String raspberryURL = buildURL(label);

            JSONObject jsonData = new JSONObject();

            try {
                jsonData.put(USER_ID, getCurrentUserId());
                jsonData.put(label, recordsJson);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .addHeader("Content-Type", "text/json; Charset=UTF-8")
                    .post(body)
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    //todo check if error here is due timeout
                    Log.e(TAG, getString(R.string.server_connection_failed) + e.getMessage());
                    ACRA.getErrorReporter().handleException(new PolarException(label+ " server timeout", getApplicationContext()));
                    //todo close db cursor and connection
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, getString(R.string.server_message_sent));

                        //set all sent records as synced
                        if (label.equals(HUMIDITY_VALUES)) {
                            mHumidityDataSource.update(mHumidityCursor);
                        } else if (label.equals(TEMPERATURE_VALUES)) {
                            mTemperatureDataSource.update(mTemperatureCursor);
                        } else if (label.equals(BATTERY_VALUES)) {
                            mBatteryDataSource.update(mBatteryCursor);
                        }


                    } else {
                        Log.e(TAG, getString(R.string.server_response_failed));
                        ACRA.getErrorReporter().handleException(new PolarException(label + getString(R.string.server_response_failed), getApplicationContext()));
                    }
                }
            });
        } else {
            Toast.makeText(this, getString(R.string.network_unavailable_message),
                    Toast.LENGTH_LONG).show();
        }
    }

    private JSONArray getUnsyncedResults(Cursor cursor) {

        JSONArray resultSet     = new JSONArray();
        cursor.moveToFirst();

        while (cursor.isAfterLast() == false) {

            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for( int i=0 ;  i< totalColumn ; i++ )  {
                if( cursor.getColumnName(i) != null ) {
                    try {
                        if( cursor.getString(i) != null ) {
                          //  Log.d("TAG_NAME", cursor.getString(i));

                            String columnName = cursor.getColumnName(i);
                            if (columnName.equals("creationDate")){
                                rowObject.put( columnName, cursor.getLong(i));
                            }
                            else if (columnName.equals("degrees")){
                                rowObject.put( columnName, cursor.getFloat(i));
                            }
                            else if (columnName.equals("value")){
                                rowObject.put( columnName, cursor.getFloat(i));
                            }
                            else {
                                rowObject.put( columnName, cursor.getInt(i));
                            }
                        }
                        else {
                            rowObject.put( cursor.getColumnName(i) ,  "" );
                        }
                    }
                    catch( Exception e ) {
                        Log.d("TAG_NAME", e.getMessage()  );
                    }
                }
            }
            resultSet.put(rowObject);
            cursor.moveToNext();
        }

        return resultSet;
    }

    private String buildURL(String dataType) {
        if (dataType.equals(TEMPERATURE_VALUES)) { return buildTemperatureURL();}
        if (dataType.equals(HUMIDITY_VALUES)) { return buildHumidityURL();}
        if (dataType.equals(BATTERY_VALUES)) { return buildBatteryURL();}
        return "";
    }

    private String buildTemperatureURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/temperature";
    }
    private String buildHumidityURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/humidity";
    }
    private String buildBatteryURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/battery";
    }

    private int getCurrentUserId() {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        return sharedPref.getInt(getString(R.string.pref_current_user_id), 0);
    }

}
