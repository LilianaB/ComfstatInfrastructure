package com.laboratory.thermalcomfort.arduino;

import java.util.HashMap;

/**
 * Created by Liliana Barrios on 07/03/16.
 */
public class GattAttributes {

    private static HashMap<String, String> attributes = new HashMap();

    public static String ENVIRONMENTAL_SENSING_SERVICE = "0000181a-0000-1000-8000-00805f9b34fb";
    public static String HUMIDITY = "00002a6f-0000-1000-8000-00805f9b34fb";
    public static String TEMPERATURE = "00002a6e-0000-1000-8000-00805f9b34fb";
    public static String CLIENT_CHARACTERISTIC_CONFIG = "00002902-0000-1000-8000-00805f9b34fb";

    public static String BATTERY_SERVICE = "0000180f-0000-1000-8000-00805f9b34fb";
    public static String BATTERY_LEVEL = "00002a19-0000-1000-8000-00805f9b34fb";

    static {
        // Services.
        attributes.put("0000180d-0000-1000-8000-00805f9b34fb", "Environmental Sensing Service");
        attributes.put("0000180f-0000-1000-8000-00805f9b34fb", "Battery Service");
        // Characteristics.
        attributes.put(HUMIDITY, "Humidity");
        attributes.put(TEMPERATURE, "Temperature");
        attributes.put(BATTERY_LEVEL, "Battery Level");
    }

    public static String lookup(String uuid, String defaultName) {
        String name = attributes.get(uuid);
        return name == null ? defaultName : name;
    }
}
