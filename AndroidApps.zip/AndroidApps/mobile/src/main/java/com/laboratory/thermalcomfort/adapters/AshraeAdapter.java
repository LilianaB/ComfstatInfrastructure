package com.laboratory.thermalcomfort.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.models.ThermalComfort;

/**
 * Created by Liliana Barrios on 01/10/15.
 */
public class AshraeAdapter extends BaseAdapter {

    private Context mContext;
    private ThermalComfort mAshraes[];

    public AshraeAdapter(Context context, ThermalComfort ashraes[]) {
        mContext = context;
        mAshraes = ashraes;

    }
    @Override
    public int getCount() {
        return mAshraes.length;
    }

    @Override
    public Object getItem(int position) {
        return mAshraes[position];
    }

    @Override
    public long getItemId(int position) {
        return 0; //can be use to tag for references
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.thermal_comfort_list_item, null);
            holder = new ViewHolder();
            holder.iconImageView = (ImageView)convertView.findViewById(R.id.iconImageView);
            holder.ashraeTextView = (TextView)convertView.findViewById(R.id.ashreaLabel);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder)convertView.getTag();
        }

        ThermalComfort thermalComfort = mAshraes[position];
        holder.iconImageView.setImageResource(ThermalComfort.getIconId(thermalComfort.getName()));
        holder.ashraeTextView.setText(thermalComfort.getName());
        convertView.setBackgroundColor(Color.parseColor(ThermalComfort.getColor(thermalComfort.getName())));
        return convertView;
    }

    private static class ViewHolder {
        ImageView iconImageView;
        TextView ashraeTextView;
    }
}
