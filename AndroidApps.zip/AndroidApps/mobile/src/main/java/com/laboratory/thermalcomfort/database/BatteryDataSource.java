package com.laboratory.thermalcomfort.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import com.laboratory.thermalcomfort.models.Battery;

import java.util.ArrayList;

/**
 * Created by Liliana Barrios on 08/03/16.
 */
public class BatteryDataSource {

    private DBSqliteHelper mDBSqliteHelper;
    private static final String TAG = BatteryDataSource.class.getSimpleName();

    public BatteryDataSource(Context context) {
        mDBSqliteHelper = new DBSqliteHelper(context);
    }

    private SQLiteDatabase open() {
        return mDBSqliteHelper.getWritableDatabase();
    }

    private void close(SQLiteDatabase db) {
        db.close();
    }

    public ArrayList<Battery> read() {
        SQLiteDatabase db = open();
        Cursor cursor = db.query(
                DBSqliteHelper.BATTERY_TABLE,
                new String[]{BaseColumns._ID, DBSqliteHelper.COLUMN_BATTERY_LEVEL,
                        DBSqliteHelper.COLUMN_BATTERY_CREATION_DATE, DBSqliteHelper.COLUMN_BATTERY_SYNC},
                null, //selection
                null, //selection args
                null, //group by
                null, //having
                null); //order

        ArrayList<Battery> batteryRecords = new ArrayList<Battery>();
        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                Battery battery = new Battery(getIntFromColumnName(cursor, BaseColumns._ID),
                        getIntFromColumnName(cursor, DBSqliteHelper.COLUMN_BATTERY_LEVEL),
                        getLongFromColumnName(cursor, DBSqliteHelper.COLUMN_BATTERY_CREATION_DATE),
                        getIntFromColumnName(cursor, DBSqliteHelper.COLUMN_BATTERY_SYNC)
                );
                batteryRecords.add(battery);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();
        db.close();
        return batteryRecords;
    }

    public  Cursor getCursor() {

        SQLiteDatabase db = open();

        String whereClause = DBSqliteHelper.COLUMN_BATTERY_SYNC + "=?";

        Cursor cursor = db.query(
                DBSqliteHelper.BATTERY_TABLE,
                new String[]{BaseColumns._ID, DBSqliteHelper.COLUMN_BATTERY_LEVEL,
                        DBSqliteHelper.COLUMN_BATTERY_CREATION_DATE , DBSqliteHelper.COLUMN_BATTERY_SYNC},
                whereClause,
                new String[] {String.valueOf(0)},
                null, //group by
                null, //having
                null); //order
        //db.close();
        return cursor;
    }

    public void update(Cursor cursor) {
        Log.d(TAG, "Updating Records");

        SQLiteDatabase db = open();
        db.beginTransaction();

        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                int recordId = getIntFromColumnName(cursor, BaseColumns._ID);
                ContentValues cv = new ContentValues();
                cv.put(DBSqliteHelper.COLUMN_BATTERY_SYNC,1);
                db.update(DBSqliteHelper.BATTERY_TABLE,
                        cv,
                        "_id="+recordId,
                        null);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();

        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

    public void create(Battery battery) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        ContentValues batteryValues = new ContentValues();
        batteryValues.put(DBSqliteHelper.COLUMN_BATTERY_LEVEL, battery.getLevel());
        batteryValues.put(DBSqliteHelper.COLUMN_BATTERY_CREATION_DATE, battery.getCreationDate());
        batteryValues.put(DBSqliteHelper.COLUMN_BATTERY_SYNC, 0);
        long memeID = db.insert(DBSqliteHelper.BATTERY_TABLE, null, batteryValues);

        db.setTransactionSuccessful();
        db.endTransaction();
        close(db);

    }

    private int getIntFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getInt(columnIndex);
    }

    private Long getLongFromColumnName(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        return cursor.getLong(columnIndex);
    }

    public void delete(int batteryId) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        //String format is the where clause of the query
        db.delete(DBSqliteHelper.BATTERY_TABLE,
                String.format("%s=%s", BaseColumns._ID,
                        String.valueOf(batteryId)),
                null);
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

}
