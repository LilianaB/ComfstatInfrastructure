package com.laboratory.thermalcomfort.location;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

import com.laboratory.thermalcomfort.alarm.BootHeartRateReceiver;
import com.laboratory.thermalcomfort.alarm.BootNotificationReceiver;
import com.laboratory.thermalcomfort.arduino.ArduinoSchedulingService;

/**
 * Created by Liliana Barrios on 21/03/16.
 */
public class WifiAlarmReceiver extends WakefulBroadcastReceiver {

        private static final int FIVE_MINUTES_INTERVAL = 5;
        private static final String TAG = WifiAlarmReceiver.class.getSimpleName();
        public static final int ALARM_ID = 1;

        private AlarmManager mAlarmMgr; // provides access to the system alarm services.
        private PendingIntent mAlarmIntent;// The pending intent, triggered when the alarm fires.

        @Override
        public void onReceive(Context context, Intent intent) {
            Intent service = new Intent(context, WifiSchedulingService.class);
            startWakefulService(context, service);
        }

        public void setAlarm(Context context) {

            long frequency;
            Log.d(TAG, "Set wifi alarm");
            frequency = FIVE_MINUTES_INTERVAL * 60 * 1000; //for testing only
            setAlarmHelper(context, frequency);

        }

        private void setAlarmHelper(Context context, long frequency) {
            mAlarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, WifiAlarmReceiver.class);
            mAlarmIntent = PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);

            // set alarm frequency depending on user preferences
            mAlarmMgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    frequency,
                    frequency, mAlarmIntent);

            // Enable {@code BootWifiAlarmReceiver} to automatically restart the alarm when the
            // device is rebooted.
            ComponentName receiver = new ComponentName(context, BootWifiAlarmReceiver.class);
            PackageManager pm = context.getPackageManager();

            pm.setComponentEnabledSetting(receiver,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP);
        }

        public void cancelAlarm(Context context) {
            AlarmManager alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, WifiAlarmReceiver.class);
            PendingIntent alarmIntent = PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);

            // If the alarm has been set, cancel it.
            if (alarmMgr!= null) {
                alarmMgr.cancel(alarmIntent);
                alarmIntent.cancel();
                Log.d(TAG, "Cancelled location alarm");
            }

            // Disable {@code BootHeartRateReceiver} so that it doesn't automatically restart the
            // alarm when the device is rebooted.
            ComponentName receiver = new ComponentName(context, BootWifiAlarmReceiver.class);
            PackageManager pm = context.getPackageManager();

            pm.setComponentEnabledSetting(receiver,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP);
        }
    }

