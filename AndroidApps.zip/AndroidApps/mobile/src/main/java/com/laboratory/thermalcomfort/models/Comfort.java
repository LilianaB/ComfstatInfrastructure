package com.laboratory.thermalcomfort.models;

import android.os.Parcel;
import android.os.Parcelable;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Liliana Barrios on 01/10/15.
 */
public class Comfort implements Parcelable {

    private int mInt;
    private int mUserId;
    private int mComfortValue;
    private String mCreationDate;
    private String mUsername;
    private double mTemperature;

    public Comfort() {
    }

    public Comfort(int anInt, int userId, int comfortValue, String creationDate, String username, double temperature) {
        mInt = anInt;
        mUserId = userId;
        mComfortValue = comfortValue;
        mCreationDate = creationDate;
        mUsername = username;
        mTemperature = temperature;
    }

    public int getInt() {
        return mInt;
    }

    public void setInt(int anInt) {
        mInt = anInt;
    }

    public int getUserId() {
        return mUserId;
    }

    public void setUserId(int userId) {
        mUserId = userId;
    }

    public int getComfortValue() {
        return mComfortValue;
    }

    public void setComfortValue(int comfortValue) {
        mComfortValue = comfortValue;
    }

    public String getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(String creationDate) {
        mCreationDate = creationDate;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public double getTemperature() {
        return mTemperature;
    }

    public void setTemperature(double temperature) {
        mTemperature = temperature;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mInt);
        dest.writeInt(mUserId);
        dest.writeInt(mComfortValue);
        dest.writeString(mCreationDate);
        dest.writeString(mUsername);
        dest.writeDouble(mTemperature);

    }

    //private constructure to read in from parcel
    private Comfort(Parcel in) {
        mInt = in.readInt();
        mUserId = in.readInt();
        mComfortValue = in.readInt();
        mCreationDate = in.readString();
        mUsername = in.readString();
        mTemperature = in.readDouble();
    }

    //create method required for PARCELABLE
    public static final Creator<Comfort> CREATOR = new Creator<Comfort>() {
        @Override
        public Comfort createFromParcel(Parcel source) {
            return new Comfort(source);
        }

        @Override
        public Comfort[] newArray(int size) {
            return new Comfort[size];
        }
    };
}
