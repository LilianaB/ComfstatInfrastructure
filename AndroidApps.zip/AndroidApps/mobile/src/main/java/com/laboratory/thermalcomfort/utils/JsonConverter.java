package com.laboratory.thermalcomfort.utils;

import android.database.Cursor;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by Liliana Barrios on 22/03/16.
 */
public class JsonConverter {

    public static JSONArray getUnsyncedResults(Cursor cursor) {

        JSONArray resultSet     = new JSONArray();
        cursor.moveToFirst();

        while (cursor.isAfterLast() == false) {

            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for( int i=0 ;  i< totalColumn ; i++ )  {
                if( cursor.getColumnName(i) != null ) {
                    try {
                        if( cursor.getString(i) != null ) {
                            //  Log.d("TAG_NAME", cursor.getString(i));

                            String columnName = cursor.getColumnName(i);
                            if (columnName.equals("creationDate")){
                                rowObject.put( columnName, cursor.getLong(i));
                            }
                            else if (columnName.equals("rrInterval") || columnName.equals("connectedTo")
                                    || columnName.equals("availableWifi")){
                                rowObject.put( columnName, cursor.getString(i));
                            }
                            else {
                                rowObject.put( columnName, cursor.getInt(i));
                            }
                        }
                        else {
                            rowObject.put( cursor.getColumnName(i) ,  "" );
                        }
                    }
                    catch( Exception e ) {
                        Log.d("TAG_NAME", e.getMessage());
                    }
                }
            }
            resultSet.put(rowObject);
            cursor.moveToNext();
        }
        //cursor.close();
        //Log.d("TAG_NAME", resultSet.toString() );
        return resultSet;
    }
}
