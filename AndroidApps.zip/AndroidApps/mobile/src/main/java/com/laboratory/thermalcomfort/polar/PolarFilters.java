package com.laboratory.thermalcomfort.polar;

import java.util.UUID;

/**
 * Created by Liliana Barrios on 03/03/16.
 */
public final class PolarFilters {

    public final static String ACTION_GATT_CONNECTED =
            "thermalcomfort.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "thermalcomfort.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "thermalcomfort.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "thermalcomfort.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "thermalcomfort.bluetooth.le.EXTRA_DATA";
    public final static String RR_DATA =
            "thermalcomfort.bluetooth.le.RR_DATA";



    public final static UUID UUID_HEART_RATE_MEASUREMENT =
            UUID.fromString(HeartRateGattAttributes.HEART_RATE_MEASUREMENT);

}
