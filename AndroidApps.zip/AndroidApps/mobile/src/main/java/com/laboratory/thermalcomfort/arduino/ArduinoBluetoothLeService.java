
package com.laboratory.thermalcomfort.arduino;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.database.BatteryDataSource;
import com.laboratory.thermalcomfort.database.HumidityDataSource;
import com.laboratory.thermalcomfort.database.TemperatureDataSource;
import com.laboratory.thermalcomfort.models.Battery;
import com.laboratory.thermalcomfort.models.Humidity;
import com.laboratory.thermalcomfort.models.Temperature;
import com.laboratory.thermalcomfort.utils.Constants;
import com.laboratory.thermalcomfort.utils.TimeUtil;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;

import static com.laboratory.thermalcomfort.arduino.ArduinoFilters.*;
import static com.laboratory.thermalcomfort.utils.Constants.BLE_ACTIVITY_CONNECTED;
import static com.laboratory.thermalcomfort.utils.Constants.BLE_ACTIVITY_CONNECTION_FAILED;
import static com.laboratory.thermalcomfort.utils.Constants.BLE_NO_SENSOR;
import static com.laboratory.thermalcomfort.utils.Constants.EXTRAS_DEVICE_ADDRESS;


/**
 * Service for managing connection and data communication with a GATT server hosted on a
 * given Bluetooth LE device.
 */
// A service that interacts with the BLE device via the Android BLE API.
public class ArduinoBluetoothLeService extends Service {

    private final static String TAG = ArduinoBluetoothLeService.class.getSimpleName();

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    private int mConnectionState = BLE_ACTIVITY_CONNECTION_FAILED;
    Queue<BluetoothGattCharacteristic> mDesiredCharacteristics;


    private Messenger messageHandler;
    private boolean mConnected = false;
    private BluetoothGattCharacteristic mNotifyCharacteristic;

    private Map<String,BluetoothGattCharacteristic> gattCharacteristicsMap = new HashMap<String,BluetoothGattCharacteristic>();
    private boolean requestFromActivity;

    static final ArduinoAlarmReceiver mArduinoAlarmReceiver = new ArduinoAlarmReceiver();

    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change and services discovered.
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                intentAction = ACTION_GATT_CONNECTED;
                mConnectionState = BLE_NO_SENSOR;
                broadcastUpdate(intentAction);
                Log.i(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Log.i(TAG, "Attempting to start service discovery:" +
                        mBluetoothGatt.discoverServices());

                //setRepeatingAlarm
                 mArduinoAlarmReceiver.setAlarm(getApplicationContext());

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                intentAction = ACTION_GATT_DISCONNECTED;
                mConnectionState = BLE_ACTIVITY_CONNECTION_FAILED;
                Log.i(TAG, "Disconnected from GATT server.");
                broadcastUpdate(intentAction);
                mArduinoAlarmReceiver.cancelAlarm(getApplicationContext());
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.w(TAG, "onServicesDiscovered success: " + status);
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {

            Log.d(TAG, "on read callback");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }
    };

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);

    }

    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);

        // This is special handling for the Heart Rate Measurement profile.  Data parsing is
        // carried out as per profile specifications:
        // http://developer.bluetooth.org/gatt/characteristics/Pages/CharacteristicViewer.aspx?u=org.bluetooth.characteristic.heart_rate_measurement.xml
        if (UUID.fromString(GattAttributes.TEMPERATURE).equals(characteristic.getUuid())) {

            final byte[] data = characteristic.getValue();
            intent.putExtra(DATA_TYPE, DATA_TEMPERATURE);
            intent.putExtra(EXTRA_DATA, new String(data));

        } else if (UUID.fromString(GattAttributes.HUMIDITY).equals(characteristic.getUuid())) {

            final byte[] data = characteristic.getValue();
            //Log.d(TAG, new String(data));
            intent.putExtra(DATA_TYPE, DATA_HUMIDITY);
            intent.putExtra(EXTRA_DATA, new String(data));

        } else if (UUID.fromString(GattAttributes.BATTERY_LEVEL).equals(characteristic.getUuid())) {

            int batteryLevel = characteristic.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, 0);
            //Log.v(TAG, "characteristic.getStringValue(0) = " + batteryLevel);
            intent.putExtra(DATA_TYPE, DATA_BATTERY);
            intent.putExtra(EXTRA_DATA, batteryLevel);

        } else {
            // For all other profiles, writes the data formatted in HEX.
            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0) {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for(byte byteChar : data)
                    stringBuilder.append(String.format("%02X ", byteChar));
                Log.d(TAG,new String(data) + "\n" + stringBuilder.toString() );
                intent.putExtra(EXTRA_DATA, new String(data));
            }
        }

        sendBroadcast(intent);
    }


    public class LocalBinder extends Binder {
        ArduinoBluetoothLeService getService() {
            return ArduinoBluetoothLeService.this;
        }
    }

    @Override
    public int onStartCommand (Intent intent, int flags, int startId) {
        super.onCreate();
        String mDeviceAddress;
        Log.d(TAG, "OnStartCommand with intent ");
        if (intent != null) {

            requestFromActivity = true;
            mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);
            messageHandler = (Messenger) intent.getParcelableExtra("MESSENGER");
            Log.d(TAG, "OnStartCommand with intent " + mDeviceAddress);

        } else {

            requestFromActivity = false;
            SharedPreferences sharedPref = getSharedPreferences(
                    "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
            mDeviceAddress = sharedPref.getString(getString(R.string.pref_current_arduino_bluetooth_device_address), "");
            Log.d(TAG, "OnStartCommand without intent " + mDeviceAddress);

        }


        if(initialize()) {
            connect(mDeviceAddress);
            registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        }

        //return sticky to startservice automatically after failure
        return START_STICKY;
    }


    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }

    private final IBinder mBinder = new LocalBinder();

    /**
     * Initializes a reference to the local Bluetooth adapter.
     *
     * @return Return true if the initialization is successful.
     */
    public boolean initialize() {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     *
     * @param address The device address of the destination device.
     *
     * @return Return true if the connection is initiated successfully. The connection result
     *         is reported asynchronously through the
     *         {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     *         callback.
     */
    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        // Previously connected device.  Try to reconnect.
        if (mBluetoothDeviceAddress != null && address.equals(mBluetoothDeviceAddress)
                && mBluetoothGatt != null) {
            Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
            if (mBluetoothGatt.connect()) {
                mConnectionState = BLE_ACTIVITY_CONNECTED;

                return true;
            } else {
                return false;
            }
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        if (device == null) {
            Log.w(TAG, "Device not found.  Unable to connect.");
            return false;
        }
        // We want to  auto-connect the device, so we are setting the autoConnect
        // parameter to true
        mBluetoothGatt = device.connectGatt(this, true, mGattCallback);
        Log.d(TAG, "Trying to create a new connection.");
        mBluetoothDeviceAddress = address;
        mConnectionState = BLE_ACTIVITY_CONNECTED;

        return true;
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(mGattUpdateReceiver);
        close();
        mArduinoAlarmReceiver.cancelAlarm(getApplicationContext());
        super.onDestroy();
    }


    /**
     * Disconnects an existing connection or cancel a pending connection. The disconnection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.disconnect();
    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    /**
     * Request a read on a given {@code BluetoothGattCharacteristic}. The read result is reported
     * asynchronously through the {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
     * callback.
     *
     * @param characteristic The characteristic to read from.
     */
    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        Log.d(TAG, "read characteristic");
        mBluetoothGatt.readCharacteristic(characteristic);
    }


    /**
     * Enables or disables notification on a give characteristic.
     *
     * @param characteristic Characteristic to act on.
     * @param enabled If true, enable notification.  False otherwise.
     */
    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);

        // enable notifications
        Log.d(TAG, "CCDD " + characteristic.getUuid().toString());
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(
                UUID.fromString(GattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        mBluetoothGatt.writeDescriptor(descriptor);
    }

    /**
     * Retrieves a list of supported GATT services on the connected device. This should be
     * invoked only after {@code BluetoothGatt#discoverServices()} completes successfully.
     *
     * @return A {@code List} of supported services.
     */
    public List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;

        return mBluetoothGatt.getServices();
    }

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (ACTION_GATT_CONNECTED.equals(action)) {
                Log.d(TAG, "GATT receiver connected");
                mConnected = true;
                if(requestFromActivity) {
                    sendMessage(Constants.BLE_ACTIVITY_CONNECTED);
                }
                updateArduinoConnectionGlobalStatus(true);
            } else if (ACTION_GATT_DISCONNECTED.equals(action)) {
                Log.d(TAG, "GATT receiver disconnected");
                if(requestFromActivity) {
                    sendMessage(Constants.BLE_ACTIVITY_CONNECTION_FAILED);
                }
                updateArduinoConnectionGlobalStatus(false);

            } else if (ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                Log.d(TAG, "GATT receiver discover services");
                // Show all the supported services and characteristics on the user interface.
                getSupportedGattServices(getSupportedGattServices());
            } else if (ACTION_DATA_AVAILABLE.equals(action)) {

                if (mDesiredCharacteristics.peek() != null) {
                    //activate characteristic notifications synchronously
                    enableNotifications(mDesiredCharacteristics.peek());
                }

                String dataType =  intent.getStringExtra(DATA_TYPE);

                if (dataType.equals(DATA_TEMPERATURE)) {
                    float temperature = Float.parseFloat(intent.getStringExtra(EXTRA_DATA));
                    Log.d(TAG, "broadcast temperature "+ temperature);

                    Temperature temperatureRecord = new Temperature(-1, temperature, TimeUtil.currentTime(), 0);
                    createTemperatureDBRecord(temperatureRecord);

                } else if (dataType.equals(DATA_HUMIDITY)){
                    float humidity = Float.parseFloat(intent.getStringExtra(EXTRA_DATA));
                    Log.d(TAG, "broadcast humidity "+ humidity);

                    Humidity humidityRecord = new Humidity(-1, humidity, TimeUtil.currentTime(), 0);
                    createHumidityDBRecord(humidityRecord);

                } else if (dataType.equals(DATA_BATTERY)) {
                    int batteryLevel = intent.getIntExtra(EXTRA_DATA, 0);
                    Log.d(TAG, "broadcast battery "+ batteryLevel);

                    Battery batteryRecord = new Battery(-1, batteryLevel, TimeUtil.currentTime(),0);
                    createBatteryDBRecord(batteryRecord);
                }

            }
        }
    };

    private void createTemperatureDBRecord(Temperature temperature) {
        TemperatureDataSource temperatureDataSource = new TemperatureDataSource(this);
        temperatureDataSource.create(temperature);
    }

    private void createHumidityDBRecord(Humidity humidity) {
        HumidityDataSource humidityDataSource = new HumidityDataSource(this);
        humidityDataSource.create(humidity);
    }

    private void createBatteryDBRecord(Battery battery) {
        BatteryDataSource batteryDataSource = new BatteryDataSource(this);
        batteryDataSource.create(battery);
    }

    // Iterate through the supported GATT Services/Characteristics and select desired characteristics
    private void getSupportedGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        String uuid = null;
        boolean hasEnvironmentService = false;
        boolean hasBatteryService = false;


        mDesiredCharacteristics = new LinkedList<BluetoothGattCharacteristic>();

        // Loops through available GATT Services.
        for (BluetoothGattService gattService : gattServices) {
            HashMap<String, String> currentServiceData = new HashMap<String, String>();
            uuid = gattService.getUuid().toString();

            Log.d(TAG, uuid);
            List<BluetoothGattCharacteristic> gattCharacteristics =
                    gattService.getCharacteristics();

            if (uuid.equals(GattAttributes.ENVIRONMENTAL_SENSING_SERVICE)) {

                Log.d(TAG, "Environmental Sensing service detected");
                hasEnvironmentService = true;

                mDesiredCharacteristics.add(
                        getSpecificCharacteristic(gattCharacteristics, GattAttributes.TEMPERATURE));
                mDesiredCharacteristics.add(
                        getSpecificCharacteristic(gattCharacteristics, GattAttributes.HUMIDITY));


            } else if (uuid.equals(GattAttributes.BATTERY_SERVICE)){

                Log.d(TAG, "Battery service detected");
                hasBatteryService = true;
                mDesiredCharacteristics.add(
                        getSpecificCharacteristic(gattCharacteristics, GattAttributes.BATTERY_LEVEL));
            }
        }

        if (!(hasEnvironmentService && hasBatteryService)) {
            Log.d(TAG, "Environment Service unavailable");
            if (mConnected) {
                close();
                updateArduinoConnectionGlobalStatus(false);
                if (requestFromActivity) {
                    sendMessage(Constants.BLE_NO_SENSOR);
                }
                mConnected = false;
            }
        } else {
            enableNotifications(mDesiredCharacteristics.peek());
        }
    }

    private BluetoothGattCharacteristic getSpecificCharacteristic( List<BluetoothGattCharacteristic> gattCharacteristics, String specificCharacteristic ) {
        // Loops through available Characteristics.
        for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
            HashMap<String, String> currentCharaData = new HashMap<String, String>();
            String uuid = gattCharacteristic.getUuid().toString();

            if (uuid.equals(specificCharacteristic)) {
                Log.d(TAG, GattAttributes.lookup(specificCharacteristic, " DEFAULT NAME ") +" characteristic detected");
                return gattCharacteristic;
            }
        }
        return null;
    }

    private boolean enableNotifications( BluetoothGattCharacteristic characteristic) {
        boolean enabled = false;

        if (characteristic == null) {
            return enabled;
        }

        final int charaProp = characteristic.getProperties();

        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
            Log.d(TAG, "READ");
            readCharacteristic(characteristic);
        }
        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
            setCharacteristicNotification(
                    characteristic, true);
            enabled = true;
        }

        mDesiredCharacteristics.poll();
        return enabled;
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_GATT_CONNECTED);
        intentFilter.addAction(ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(ACTION_DATA_AVAILABLE);
        return intentFilter;
    }

    public void sendMessage(int state) {
        Log.d(TAG, state + "");
        Message message = Message.obtain();
        switch (state) {
            case Constants.BLE_ACTIVITY_CONNECTED:
                message.arg1 = Constants.BLE_ACTIVITY_CONNECTED;
                break;
            case Constants.BLE_ACTIVITY_CONNECTION_FAILED:
                message.arg1 = Constants.BLE_ACTIVITY_CONNECTION_FAILED;
                break;
            case Constants.BLE_NO_SENSOR:
                message.arg1 = Constants.BLE_NO_SENSOR;
        }
        try {
            messageHandler.send(message);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private void updateArduinoConnectionGlobalStatus(boolean connected) {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(getString(R.string.pref_arduino_bluetooth_state), connected);
        editor.commit();
    }
}
