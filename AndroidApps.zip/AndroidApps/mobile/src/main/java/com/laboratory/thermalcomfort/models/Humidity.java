package com.laboratory.thermalcomfort.models;

/**
 * Created by Liliana Barrios on 09/03/16.
 */
public class Humidity {

    private int mId;
    private float mValue;
    private long mCreationDate;
    private int mSync;

    public Humidity(int id, float value, long creationDate, int sync) {
        mId = id;
        mValue = value;
        mCreationDate = creationDate;
        mSync = sync;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public float getValue() {
        return mValue;
    }

    public void setValue(float value) {
        mValue = value;
    }

    public long getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(long creationDate) {
        mCreationDate = creationDate;
    }

    public int getSync() {
        return mSync;
    }

    public void setSync(int sync) {
        mSync = sync;
    }
}
