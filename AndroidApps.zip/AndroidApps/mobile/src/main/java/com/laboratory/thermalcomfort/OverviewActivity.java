package com.laboratory.thermalcomfort;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.laboratory.thermalcomfort.adapters.AshraeAdapter;
import com.laboratory.thermalcomfort.adapters.ComfortAdapter;
import com.laboratory.thermalcomfort.models.Comfort;
import com.laboratory.thermalcomfort.models.ThermalComfort;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.Time;
import java.util.Arrays;

import butterknife.Bind;
import butterknife.ButterKnife;

public class OverviewActivity extends ListActivity {

    private static final String TAG = OverviewActivity.class.getSimpleName();

    protected Context mContext;
    private Comfort[] mComforts = new Comfort[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overview);
        ButterKnife.bind(this);
        mContext = this;

        Intent intent = getIntent();
        Parcelable[] parcelables = intent.getParcelableArrayExtra(HomeActivity.COMFORT_LEVEL);
        if (parcelables != null) {
            mComforts = Arrays.copyOf(parcelables, parcelables.length, Comfort[].class);
        }



        ComfortAdapter comfortAdapter = new ComfortAdapter(this,mComforts );
        setListAdapter(comfortAdapter);
    }




    private void alertUserAboutError() {
        AlertDialogFragment dialog = new AlertDialogFragment();
        dialog.show(getFragmentManager(), "error_dialog");
    }
}
