package com.laboratory.thermalcomfort.polar;

import android.content.Context;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;

import com.laboratory.thermalcomfort.utils.TimeUtil;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Liliana Barrios on 10/03/16.
 */
public class PolarException  extends Exception {

    private static long ALARM_DURATION = 5000;

    public PolarException(String message, Context context) {
        super(message + ". Event at " + TimeUtil.getFormattedDate());
        playAlarm(context);
    }

    private void playAlarm(Context context) {
        Uri notification = RingtoneManager
                .getDefaultUri(RingtoneManager.TYPE_ALARM);
        final Ringtone alarmRingtone = RingtoneManager
                .getRingtone(context, notification);
        alarmRingtone.play();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                alarmRingtone.stop();
            }
        };
        Timer timer = new Timer();
        timer.schedule(task, ALARM_DURATION);
    }
}
