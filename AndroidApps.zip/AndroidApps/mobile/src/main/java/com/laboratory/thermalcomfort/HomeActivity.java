package com.laboratory.thermalcomfort;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.Toast;

import com.laboratory.thermalcomfort.alarm.NotificationAlarmReceiver;
import com.laboratory.thermalcomfort.alarm.HeartRateAlarmReceiver;
import com.laboratory.thermalcomfort.database.DBSqliteHelper;
import com.laboratory.thermalcomfort.models.Comfort;
import com.laboratory.thermalcomfort.utils.FileUtil;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class HomeActivity extends Activity {

    public static final String TAG = HomeActivity.class.getSimpleName();
    public static final String COMFORT_LEVEL = "COMFORT_LEVEL";

    @Bind(R.id.voteImageButton) ImageButton mVoteButton;

    private String mRaspberryPiUrl;
    private Comfort[] mComforts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        ButterKnife.bind(this);

        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        fetchLastVotes();
    }

    @OnClick(R.id.voteImageButton)
    public void goToVoteActivity() {
        Intent intent = new Intent(this, ThermalComfortActivity.class);
        startActivity(intent);

    }

    @OnClick(R.id.statsImageButton)
    public void goToStatsActivity() {
        Intent intent = new Intent(this, EnvironmentActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.settingsImageButton)
    public void goToPreferenceFragment() {
        Intent intent = new Intent(this, NotificationPreferenceFragment.class);
        startActivity(intent);
    }

    @OnClick(R.id.heartRateimageButton)
    public void goToHeartRateActivity() {
        Intent intent = new Intent(this, HeartRateActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.overviewImageButton)
    public void goToOverview() {
        Intent intent = new Intent(this, OverviewActivity.class);
        intent.putExtra(COMFORT_LEVEL,mComforts);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_settings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {
            logoutHelper();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void logoutHelper() {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(getString(R.string.pref_is_user_logged), false);
        editor.commit();

        NotificationAlarmReceiver mNotificationAlarmReceiver = new NotificationAlarmReceiver();
        HeartRateAlarmReceiver mHRAlarmReceiver = new HeartRateAlarmReceiver();

        mNotificationAlarmReceiver.cancelAlarm(this);
        mHRAlarmReceiver.cancelAlarm(this);

        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void fetchLastVotes() {
        String raspberryURL = buildURL();

        if (NetworkUtil.isNetworkAvailable(this)) {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    Log.d(TAG, "Failed to connect to server");
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    try {
                        String jsonData = response.body().string();

                        Log.v(TAG, jsonData);
                        if (response.isSuccessful()) {
                            Log.d(TAG, "success");
                            processData(jsonData);

                        } else {
                            Log.d(TAG, "unsuccessful response");
                        }
                    } catch (IOException e) {
                        Log.e(TAG, "Exception caught: ", e);
                    } catch (JSONException e) {
                        Log.e(TAG, "Exception caught: ", e);
                    }
                }
            });
        } else {
            Toast.makeText(this, R.string.network_unavailable_message, Toast.LENGTH_LONG).show();
        }
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/vote";
    }

    private  void processData(String jsonData) throws JSONException {
        JSONObject lastVotes = new JSONObject(jsonData);

        mComforts = new Comfort[lastVotes.length()];

        for (int i = 0; i < lastVotes.length(); i++) {
            Comfort comfort = new Comfort();

            JSONObject jsonVote = lastVotes.getJSONObject(i + "");
            comfort.setInt(-1);
            comfort.setUserId(jsonVote.getInt("id"));
            //int datee = jsonVote.getString("creation_date");
            //Log.d(TAG, datee+"");
            //comfort.setCreationDate(datee);
            comfort.setCreationDate(TimeUtil.changeDateFormat(jsonVote.getString("creation_date")));
            comfort.setComfortValue(jsonVote.getInt("comfort"));
            comfort.setUsername(jsonVote.getString("username"));
            comfort.setTemperature(jsonVote.getDouble("temperature"));

            mComforts[i] = comfort;
        }
    }
}
