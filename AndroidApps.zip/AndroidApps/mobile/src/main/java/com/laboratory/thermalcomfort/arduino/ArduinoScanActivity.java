package com.laboratory.thermalcomfort.arduino;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.adapters.LeDeviceListAdapter;

import butterknife.Bind;
import butterknife.ButterKnife;

import static com.laboratory.thermalcomfort.utils.Constants.BLE_ACTIVITY_CONNECTED;
import static com.laboratory.thermalcomfort.utils.Constants.BLE_ACTIVITY_CONNECTION_FAILED;
import static com.laboratory.thermalcomfort.utils.Constants.BLE_NO_SENSOR;

/**
 * Activity for scanning and displaying available Bluetooth LE devices.
 */
public class ArduinoScanActivity extends Activity {


    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";
    private static final String TAG = ArduinoScanActivity.class.getSimpleName();
    private static final int REQUEST_CODE_ASK_PERMISSIONS = 123; //application specific
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private Handler mHandler;
    private ListView mListView;
    private String mDeviceAddress;
    private String mDeviceName;
    Messenger messenger;



    private static final int REQUEST_ENABLE_BT = 1;
    // Stops scanning after 10 seconds.
    private static final long SCAN_PERIOD = 10000;

    @Bind(R.id.progressBar) ProgressBar mProgressBar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arduino_scan);
        ButterKnife.bind(this);
        mProgressBar.setVisibility(View.INVISIBLE);

        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        boolean deviceAlreadyConnected = sharedPref.getBoolean(getString(R.string.pref_arduino_bluetooth_state), false);

        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if (deviceAlreadyConnected) {

            String deviceName = sharedPref.getString(getString(R.string.pref_current_arduino_bluetooth_device_name), "");
            String deviceAddress = sharedPref.getString(getString(R.string.pref_current_arduino_bluetooth_device_address), "");

            Bundle bundle = new Bundle();
            bundle.putString(EXTRAS_DEVICE_NAME, deviceName );
            bundle.putString(EXTRAS_DEVICE_ADDRESS, deviceAddress);

            ArduinoFragment deviceFragment = new ArduinoFragment();
            deviceFragment.setArguments(bundle);
            fragmentTransaction.replace(R.id.fragment_container, deviceFragment);
            fragmentTransaction.commit();

        } else {

            NoArduinoFragment noDeviceFragment = new NoArduinoFragment();
            fragmentTransaction.add(R.id.fragment_container, noDeviceFragment);
            fragmentTransaction.commit();
        }


        mHandler = new Handler();


        // Use this check to determine whether BLE is supported on the device.  Then you can
        // selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
        }

        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        int hasLocationPermission = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (hasLocationPermission != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_CODE_ASK_PERMISSIONS);
            return;
        } else {
            Log.d(TAG, "Granted");
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission Granted
                    Log.d(TAG, "permission granted");
                } else {
                    // Permission Denied
                    Toast.makeText(ArduinoScanActivity.this, "ACCESS_COARSE_LOCATION Denied", Toast.LENGTH_SHORT)
                            .show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Ensures Bluetooth is enabled on the device.  If Bluetooth is not currently enabled,
        // fire an intent to display a dialog asking the user to grant permission to enable it.
        if (!mBluetoothAdapter.isEnabled()) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
        else {
            //// TODO: 09/02/16 here you can fire the thing for the permission location
        }

        mListView = (ListView) findViewById(R.id.listView);
        // Initializes list view adapter.
        mLeDeviceListAdapter = new LeDeviceListAdapter(this);
        mListView.setAdapter(mLeDeviceListAdapter);
        scanLeDevice(true);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView deviceNameTextView = (TextView) view.findViewById(R.id.device_name);
                TextView deviceAddressTextView = (TextView) view.findViewById(R.id.device_address);

                mDeviceAddress = deviceAddressTextView.getText().toString();
                mDeviceName = deviceNameTextView.getText().toString();
                Log.d(TAG, mDeviceAddress + " " + mDeviceName);

                if (mScanning) {
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    mScanning = false;
                }

                Intent gattServiceIntent = new Intent(getApplicationContext(), ArduinoBluetoothLeService.class);
                gattServiceIntent.putExtra(EXTRAS_DEVICE_NAME, mDeviceName);
                gattServiceIntent.putExtra(EXTRAS_DEVICE_ADDRESS, mDeviceAddress);

                Handler messageHandler = new MessageHandler();
                messenger = new Messenger(messageHandler);
                gattServiceIntent.putExtra("MESSENGER", messenger);
                saveServiceDependantData((MessageHandler) messageHandler);

                toggleProgressBar(true);
                startService(gattServiceIntent);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // User chose not to enable Bluetooth.
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            finish();
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        scanLeDevice(false);
        mLeDeviceListAdapter.clear();
    }

    /*@Override
    protected void onDestroy() {
        super.onDestroy();
        Intent gattServiceIntent = new Intent(this, PolarBluetoothLeService.class);
        stopService(gattServiceIntent);
    }*/

    private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    mBluetoothAdapter.stopLeScan( mLeScanCallback);
                    invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;

            // // TODO: 09/02/16 this start scanning, implement callback because this is how scan results are returned
            //mBluetoothAdapter.startLeScan(myArray, mLeScanCallback);
            mBluetoothAdapter.startLeScan( mLeScanCallback);
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
        invalidateOptionsMenu();
    }

    // Device scan callback.
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mLeDeviceListAdapter.addDevice(device);
                            mLeDeviceListAdapter.notifyDataSetChanged();
                        }
                    });
                }
            };

    public class MessageHandler extends Handler {
        @Override
        public void handleMessage(Message message) {

            int state = message.arg1;
            FragmentManager fragmentManager = getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    toggleProgressBar(false);
                }
            });

            switch (state) {
                case BLE_ACTIVITY_CONNECTED:
                    Log.d(TAG, "Message received connected");

                    Bundle bundle = new Bundle();
                    bundle.putString(EXTRAS_DEVICE_NAME, mDeviceName );
                    bundle.putString(EXTRAS_DEVICE_ADDRESS, mDeviceAddress);

                    ArduinoFragment deviceFragment = new ArduinoFragment();
                    deviceFragment.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, deviceFragment);

                    try {
                        fragmentTransaction.commit();
                    } catch (Exception e) {
                        Log.d(TAG, "Cannot attach fragment" + e.getMessage());
                    }

                    saveSessionValues(true);
                    break;

                case BLE_ACTIVITY_CONNECTION_FAILED:

                    Log.d(TAG, "Message received NOT connected");
                    setNoDeviceFragment(fragmentTransaction);
                    break;

                case BLE_NO_SENSOR:

                    Log.d(TAG, "Message received NO sensor");
                    setNoDeviceFragment(fragmentTransaction);
                    AlertDialog.Builder builder = new AlertDialog.Builder(ArduinoScanActivity.this);
                    builder.setMessage(mDeviceName + " does not have required sensor")
                            .setTitle(R.string.login_error_title)
                            .setPositiveButton(android.R.string.ok, null);
                    AlertDialog dialog = builder.create();
                    dialog.show();

            }

        }
    }

    private void setNoDeviceFragment(FragmentTransaction fragmentTransaction) {
        NoArduinoFragment noDeviceFragment = new NoArduinoFragment();
        fragmentTransaction.replace(R.id.fragment_container, noDeviceFragment);
        try {
            fragmentTransaction.commit();
        } catch (Exception e) {
            Log.d(TAG, "Cannot attach fragment" + e.getMessage());
        }
    }

    private void saveSessionValues(boolean isConnected) {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(getString(R.string.pref_current_arduino_bluetooth_device_name), mDeviceName);
        editor.putString(getString(R.string.pref_current_arduino_bluetooth_device_address), mDeviceAddress);
        editor.putBoolean(getString(R.string.pref_arduino_bluetooth_state), isConnected);
        editor.commit();
    }

    private void saveServiceDependantData(MessageHandler messenger) {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(getString(R.string.pref_current_arduino_bluetooth_device_address), mDeviceAddress);
        editor.commit();

    }

    private void toggleProgressBar(boolean show) {
        if (show) {
            mProgressBar.setVisibility(View.VISIBLE);
        }else {
            mProgressBar.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
