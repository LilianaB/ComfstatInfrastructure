package com.laboratory.thermalcomfort.utils;

import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.laboratory.thermalcomfort.NotificationIntentReceiver;

public class NotificationUtil {
    public static final String EXTRA_MESSAGE =
            "com.laboratory.thermalcomfort.MESSAGE";
    public static final String EXTRA_REPLY =
            "com.laboratory.thermalcomfort.REPLY";

    public static PendingIntent getPendingIntent(Context context, int messageResId) {
        Intent intent = new Intent(NotificationIntentReceiver.ACTION_EXAMPLE)
                .setClass(context, NotificationIntentReceiver.class);
        intent.putExtra(EXTRA_MESSAGE, context.getString(messageResId));
        return PendingIntent.getBroadcast(context, messageResId, intent,
                PendingIntent.FLAG_ONE_SHOT);
    }
}
