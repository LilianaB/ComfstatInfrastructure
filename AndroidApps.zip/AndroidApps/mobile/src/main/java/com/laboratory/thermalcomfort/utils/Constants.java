package com.laboratory.thermalcomfort.utils;

/**
 * Created by Liliana Barrios on 19/11/15.
 */
public final class Constants {

    public static final String NOTIFICATION_FREQUENCY_NONE = "none";
    public static final String NOTIFICATION_FREQUENCY_LOW = "low";
    public static final String NOTIFICATION_FREQUENCY_MEDIUM = "medium";
    public static final String NOTIFICATION_FREQUENCY_HIGH = "high";


    public static final String TOKEN = "\\|";
    public static final String HEART_RATE = "heart_rate";
    public static final String CREATION_TIME = "time";
    public static final String BATTERY = "battery";
    public static final String USER_ID = "user_id";
    public static final String ELAPSED_TIME = "elapsed_time";
    public static final String ACCURACY = "accuracy";
    public static final String START_SERVICE_PATH = "/heartrate";
    public static final String START_ACTIVITY_PATH = "/start-activity";
    public static final String WIFI_VALUES = "wifi_values";
    public static final String POLAR_VALUES = "polar_values";
    public static final String TEMPERATURE_VALUES = "temperature_values";
    public static final String HUMIDITY_VALUES = "humidity_values";
    public static final String BATTERY_VALUES = "battery_values";

    public static final int BLE_ACTIVITY_CONNECTION_FAILED = 0;
    public static final int BLE_ACTIVITY_CONNECTED = 1;
    public static final int BLE_NO_SENSOR = 2;

    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";

}
