package com.laboratory.thermalcomfort;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.laboratory.thermalcomfort.models.Environment;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class EnvironmentActivity extends Activity {

    public static final String TAG = EnvironmentActivity.class.getSimpleName();
    private Environment mCurrentEnvironment;
    private String mRaspberryPiUrl;

    @Bind(R.id.temperatureValue) TextView mTemperatureValue;
    @Bind(R.id.timeLabel) TextView mTimeLabel;
    @Bind(R.id.outdoorValue) TextView mOutdoorValue;
    @Bind(R.id.humidityValue) TextView mHumidityValue;
    @Bind(R.id.pressureValue) TextView mPressureValue;
    @Bind(R.id.progressBar) ProgressBar mProgressBar;
    @Bind(R.id.refreshImageView) ImageView mRefresh;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_environment);
            ButterKnife.bind(this);

            mProgressBar.setVisibility(View.INVISIBLE);

            mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
            getCurrentEnvironment();

    }

    @OnClick(R.id.refreshImageView)
    public void refreshDisplay() {
        getCurrentEnvironment();
    }

    private void getCurrentEnvironment() {
        String raspberryURL = buildURL();

        if (isNetworkAvailable()) {
            toggleRefresh();
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toggleRefresh();
                        }
                    });
                    alertUserAboutError();
                }

                @Override
                public void onResponse(Response response) throws IOException {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toggleRefresh();
                        }
                    });
                    try {
                        String jsonData = response.body().string();
                        Log.v(TAG, jsonData);
                        if (response.isSuccessful()) {
                            Log.d(TAG, "success");
                            mCurrentEnvironment = getCurrentDetails(jsonData);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    updateDisplay();
                                }
                            });


                        } else {
                            alertUserAboutError();
                        }
                    } catch (IOException e) {
                        Log.e(TAG, "Exception caught: ", e);
                    } catch (JSONException e) {
                        Log.e(TAG, "Exception caught: ", e);
                    }
                }
            });
        } else {
            Toast.makeText(this, R.string.network_unavailable_message, Toast.LENGTH_LONG).show();
        }
    }

    private void toggleRefresh() {
        if (mProgressBar.getVisibility() == View.INVISIBLE) {
            mProgressBar.setVisibility(View.VISIBLE);
            mRefresh.setVisibility(View.INVISIBLE);
        }else {
            mProgressBar.setVisibility(View.INVISIBLE);
            mRefresh.setVisibility(View.VISIBLE);
        }
    }

    private void updateDisplay() {
        mTemperatureValue.setText(mCurrentEnvironment.getTemperature()+"");
        mTimeLabel.setText("At "+ mCurrentEnvironment.getFormattedTime());
        mOutdoorValue.setText(mCurrentEnvironment.getTemperature()-30+"");
        mHumidityValue.setText(mCurrentEnvironment.getHumidity()+"%");
        mPressureValue.setText(mCurrentEnvironment.getPressure()+"");
    }

    private Environment getCurrentDetails(String jsonData) throws JSONException {
        JSONObject environmentData = new JSONObject(jsonData);
        Environment currentEnvironment = new Environment();

        currentEnvironment.setTemperature(environmentData.getDouble("temperature"));
        currentEnvironment.setHumidity(environmentData.getDouble("humidity"));
        currentEnvironment.setPressure(environmentData.getDouble("pressure"));
        currentEnvironment.setTime(TimeUtil.currentTime());

        return currentEnvironment;
    }


    private boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;
        if (networkInfo != null && networkInfo.isConnected()) {
            isAvailable = true;
        }

        return isAvailable;
    }

    private void alertUserAboutError() {
        AlertDialogFragment dialog = new AlertDialogFragment();
        dialog.show(getFragmentManager(), "error_dialog");
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/environment";
    }

}
