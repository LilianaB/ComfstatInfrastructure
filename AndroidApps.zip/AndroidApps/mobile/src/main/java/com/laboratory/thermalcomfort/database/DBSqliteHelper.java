package com.laboratory.thermalcomfort.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.provider.BaseColumns;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;

/**
 * Created by Liliana Barrios on 22/02/16.
 */
public class DBSqliteHelper extends SQLiteOpenHelper {

    private static final String TAG = DBSqliteHelper.class.getSimpleName();

    public static final String DB_NAME = "ThermalComfort.db";
    private static final int DB_VERSION = 1;

    private static final String TEXT_TYPE = " TEXT";
    private static final String INTEGER_TYPE = " INTEGER";
    private static final String BLOB_TYPE = " BLOB";
    private static final String REAL_TYPE = " REAL";
    private static final String COMMA_SEP = ",";


    //Polar Strap Table
    public static final String POLAR_TABLE = "polar";
    public static final String COLUMN_POLAR_HR = "heartRate";
    public static final String COLUMN_POLAR_RR_INTERVAL = "rrInterval";
    public static final String COLUMN_POLAR_CREATION_DATE = "creationDate";
    public static final String COLUMN_POLAR_SYNC = "sync";
    private static String CREATE_POLAR =
            "CREATE TABLE " +POLAR_TABLE + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_POLAR_HR +INTEGER_TYPE+ COMMA_SEP +
                    COLUMN_POLAR_RR_INTERVAL + BLOB_TYPE+ COMMA_SEP +
                    COLUMN_POLAR_CREATION_DATE + REAL_TYPE+ COMMA_SEP +
                    COLUMN_POLAR_SYNC+ INTEGER_TYPE+")";

    //Temperature Table
    public static final String TEMPERATURE_TABLE = "temperature";
    public static final String COLUMN_TEMPERATURE_DEGREES = "degrees";
    public static final String COLUMN_TEMPERATURE_CREATION_DATE = "creationDate";
    public static final String COLUMN_TEMPERATURE_SYNC = "sync";
    private static String CREATE_TEMPERATURE =
            "CREATE TABLE " +TEMPERATURE_TABLE + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_TEMPERATURE_DEGREES +REAL_TYPE+ COMMA_SEP +
                    COLUMN_TEMPERATURE_CREATION_DATE + REAL_TYPE+ COMMA_SEP +
                    COLUMN_TEMPERATURE_SYNC+ INTEGER_TYPE+")";

    //Humidity Table
    public static final String HUMIDITY_TABLE = "humidity";
    public static final String COLUMN_HUMIDITY_VALUE = "value";
    public static final String COLUMN_HUMIDITY_CREATION_DATE = "creationDate";
    public static final String COLUMN_HUMIDITY_SYNC = "sync";
    private static String CREATE_HUMIDITY =
            "CREATE TABLE " +HUMIDITY_TABLE + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_HUMIDITY_VALUE +REAL_TYPE+ COMMA_SEP +
                    COLUMN_HUMIDITY_CREATION_DATE + REAL_TYPE+ COMMA_SEP +
                    COLUMN_HUMIDITY_SYNC+ INTEGER_TYPE+")";


    //Battery Table
    public static final String BATTERY_TABLE = "battery";
    public static final String COLUMN_BATTERY_LEVEL = "level";
    public static final String COLUMN_BATTERY_CREATION_DATE = "creationDate";
    public static final String COLUMN_BATTERY_SYNC = "sync";
    private static String CREATE_BATTERY =
            "CREATE TABLE " +BATTERY_TABLE + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_BATTERY_LEVEL +INTEGER_TYPE+ COMMA_SEP +
                    COLUMN_BATTERY_CREATION_DATE + REAL_TYPE+ COMMA_SEP +
                    COLUMN_BATTERY_SYNC+ INTEGER_TYPE+")";

    //Wifi Table
    public static final String WIFI_TABLE = "wifi";
    public static final String COLUMN_WIFI_CONNECTED_TO = "connectedTo";
    public static final String COLUMN_WIFI_AVAILABLE_WIFI = "availableWifi";
    public static final String COLUMN_WIFI_CREATION_DATE = "creationDate";
    public static final String COLUMN_WIFI_SYNC = "sync";
    private static String CREATE_WIFI =
            "CREATE TABLE " +WIFI_TABLE + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_WIFI_CONNECTED_TO +TEXT_TYPE+ COMMA_SEP +
                    COLUMN_WIFI_AVAILABLE_WIFI + BLOB_TYPE+ COMMA_SEP+
                    COLUMN_WIFI_CREATION_DATE + REAL_TYPE+ COMMA_SEP +
                    COLUMN_WIFI_SYNC+ INTEGER_TYPE+")";

    Context mContext;
    public DBSqliteHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION); // create DB if needed, and upgrade if version in old
        mContext = context;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // create schema for the first time
        db.execSQL(CREATE_POLAR);
        db.execSQL(CREATE_TEMPERATURE);
        db.execSQL(CREATE_HUMIDITY);
        db.execSQL(CREATE_BATTERY);
        db.execSQL(CREATE_WIFI);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
