package com.laboratory.thermalcomfort.arduino;


/**
 * Created by Liliana Barrios on 08/03/16.
 */
public class ArduinoFilters {

    public final static String ACTION_GATT_CONNECTED =
            "thermalcomfort.arduino.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "thermalcomfort.arduino.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "thermalcomfort.arduino.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "thermalcomfort.arduino.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "thermalcomfort.arduino.bluetooth.le.EXTRA_DATA";
    public final static String DATA_TYPE =
            "thermalcomfort.arduino.bluetooth.le.DATA_TYPE";
    public final static String DATA_HUMIDITY = "HUMIDITY";
    public final static String DATA_BATTERY= "BATTERY";
    public final static String DATA_TEMPERATURE = "TEMPERATURE";

}
