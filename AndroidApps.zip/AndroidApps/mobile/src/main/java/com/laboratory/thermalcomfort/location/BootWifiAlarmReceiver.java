package com.laboratory.thermalcomfort.location;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;


/**
 * Created by Liliana Barrios on 31/03/16.
 */
public class BootWifiAlarmReceiver extends BroadcastReceiver {

    WifiAlarmReceiver alarm = new WifiAlarmReceiver();
    private static final String TAG = BootWifiAlarmReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED"))
        {
            alarm.setAlarm(context);
            Log.d(TAG, "Boot Alarm system");
        }
    }
}
