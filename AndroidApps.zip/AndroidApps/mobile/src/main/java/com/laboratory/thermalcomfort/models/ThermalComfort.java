package com.laboratory.thermalcomfort.models;

import android.util.Log;

import com.laboratory.thermalcomfort.R;

import java.util.HashMap;
import java.util.LinkedHashMap;

/**
 * Created by Liliana Barrios on 30/09/15.
 */
public class ThermalComfort {

    private String mName;
    private int mAshrae;
    private String mColor;

    private static final String TAG = ThermalComfort.class.getSimpleName();
    private static final LinkedHashMap<String, Integer> ASHRAE_VALUES;
    static {
        ASHRAE_VALUES = (
                new LinkedHashMap<String, Integer>() {{
                    put("cold", -3);
                    put("cool", -2);
                    put("slightly cool", -1);
                    put("neutral", 0);
                    put("slightly warm", 1);
                    put("warm", 2);
                    put("hot", 3);
                }});
    }

    public ThermalComfort() {

    }

    public ThermalComfort(String name, int ashrae, String color) {
        mName = name;
        mAshrae = ashrae;
        mColor = color;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public int getAshrae() {
        return mAshrae;
    }

    public void setAshrae(int ashrae) {
        mAshrae = ashrae;
    }

    public static int getIconId(String mIconString) {
        int iconId = R.mipmap.ic_cold;

        if (mIconString.equals("cold")) {
            iconId = R.mipmap.ic_cold;
        }
        else if (mIconString.equals("cool")) {
            iconId = R.mipmap.ic_cool;
        }
        else if (mIconString.equals("slightly cool")) {
            iconId = R.mipmap.ic_slightcool;
        }
        else if (mIconString.equals("neutral")) {
            iconId = R.mipmap.ic_neutral;
        }
        else if (mIconString.equals("warm")) {
            iconId = R.mipmap.ic_warm;
        }
        else if (mIconString.equals("slightly warm")) {
            iconId = R.mipmap.ic_slightwarm;
        }
        else if (mIconString.equals("warm")) {
            iconId = R.mipmap.ic_warm;
        }
        else if (mIconString.equals("hot")) {
            iconId = R.mipmap.ic_hot;
        }
        return iconId;
    }

    public static int getAshrae(String comfortLevel) {
        int intLevel = 0;

        switch (comfortLevel) {
            case "cold":
                intLevel = -3;
                break;
            case "cool":
                intLevel = -2;
                break;
            case "slightly cool":
                intLevel = -1;
                break;
            case "neutral":
               intLevel = 0;
                break;
            case "slightly warm":
                intLevel = 1;
                break;
            case "warm":
                intLevel = 2;
                break;
            case "hot":
                intLevel = 3;
                break;
            default:
                break;
        }

        //Log.d(TAG, comfortLevel + " "+ intLevel);
        return intLevel;
    }

    public static String getAshraeString(int comfortLevel) {
        String stringLevel = "neutral";

        switch (comfortLevel) {
            case -3:
                stringLevel = "cold";
                break;
            case -2:
                stringLevel = "cool";
                break;
            case -1:
                stringLevel = "slightly cool";
                break;
            case 0:
                stringLevel = "neutral";
                break;
            case 1:
                stringLevel = "slightly warm";
                break;
            case 2:
                stringLevel = "warm";
                break;
            case 3:
                stringLevel = "hot";
                break;
            default:
                break;
        }

        //Log.d(TAG, comfortLevel + " "+ stringLevel);
        return stringLevel;
    }

    public static String getColor(String mIconString) {
        String iconColor = "#5262BC";

        if (mIconString.equals("cold")) {
            iconColor = "#5262BC";
        }
        else if (mIconString.equals("cool")) {
            iconColor = "#69A1FF";
        }
        else if (mIconString.equals("slightly cool")) {
            iconColor = "#35BAF6";
        }
        else if (mIconString.equals("neutral")) {
            iconColor = "#70BF73";
        }
        else if (mIconString.equals("slightly warm")) {
            iconColor = "#FFCD39";
        }
        else if (mIconString.equals("warm")) {
            iconColor = "#FFAD33";
        }
        else if (mIconString.equals("hot")) {
            iconColor = "#FF6738";
        }
        return iconColor;
    }

    public static ThermalComfort[] getThermalComfortOptions() {

        ThermalComfort[] options = new ThermalComfort[ASHRAE_VALUES.size()];
        int i = 0;
        for (HashMap.Entry<String, Integer> ashrae : ASHRAE_VALUES.entrySet()) {
            ThermalComfort newAshrae = new ThermalComfort(ashrae.getKey(), ashrae.getValue(), getColor(ashrae.getKey()));
            options[i] = newAshrae;
            i++;
        }

        return options;

    }

}
