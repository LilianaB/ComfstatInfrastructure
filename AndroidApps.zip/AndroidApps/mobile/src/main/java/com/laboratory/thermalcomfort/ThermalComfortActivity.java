package com.laboratory.thermalcomfort;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.laboratory.thermalcomfort.adapters.AshraeAdapter;
import com.laboratory.thermalcomfort.models.ThermalComfort;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.SessionUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ThermalComfortActivity extends ListActivity {

    public static final String TAG = ThermalComfort.class.getSimpleName();
    public static final String USER_ID = "user_id";
    public static final String COMFORT_LEVEL = "comfort";
    public static final String CREATION_TIME = "creation_date";


    ThermalComfort[] mThermalComfort;
    private String mRaspberryPiUrl;
    protected Context mContext;

    @Bind(R.id.progressBar)
    ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thermal_comfort);
        mThermalComfort = ThermalComfort.getThermalComfortOptions();
        ButterKnife.bind(this);
        mContext = this;


        AshraeAdapter ashraeAdapter = new AshraeAdapter(this,mThermalComfort );
        setListAdapter(ashraeAdapter);
        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
        mProgressBar.setVisibility(View.INVISIBLE);

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        toggleRefresh();
        String ashrae = mThermalComfort[position].getName();
        int ashraeValue = mThermalComfort[position].getAshrae();

        Log.d(TAG, "Ashrea" + ashraeValue);

        if (NetworkUtil.isNetworkAvailable(this)) {
            OkHttpClient client = new OkHttpClient();
            String raspberryURL = buildURL();

            JSONObject jsonData = new JSONObject();

            try {
                jsonData.put(USER_ID, SessionUtil.getCurrentUserId(this));
                jsonData.put(CREATION_TIME, TimeUtil.currentTime());
                jsonData.put(COMFORT_LEVEL, ashraeValue);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
            Request request = new Request.Builder()
                    .url(raspberryURL)
                    .addHeader("Content-Type","text/json; Charset=UTF-8")
                    .post(body)
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toggleRefresh();
                        }
                    });
                    Log.e(TAG, "Failed to connect to server " + e.getMessage());
                    alertUserAboutError();
                }

                @Override
                public void onResponse(Response response) throws IOException {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            toggleRefresh();
                        }
                    });

                    try {
                        String jsonWeatherData = response.body().string();
                        Log.v(TAG, jsonWeatherData);
                        if (response.isSuccessful()) {

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast toast = Toast.makeText(mContext, "comfort level successfully stored", Toast.LENGTH_SHORT);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                }
                            });
                            Log.d(TAG, "Created comfort record on server");
                            Intent intent = new Intent(mContext, HomeActivity.class);
                            startActivity(intent);

                        } else {
                            Log.e(TAG, "Response unsuccessful");
                            alertUserAboutError();
                        }
                    } catch (IOException e) {
                        Log.e(TAG, "Exception caught:", e);
                    }
                }
            });
        } else {
            Toast.makeText(this, getString(R.string.network_unavailable_message),
                    Toast.LENGTH_LONG).show();
        }
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/vote";
    }


    private void alertUserAboutError() {
        AlertDialogFragment dialog = new AlertDialogFragment();
        dialog.show(getFragmentManager(), "error_dialog");
    }

    private void toggleRefresh() {
        if (mProgressBar.getVisibility() == View.INVISIBLE) {
            mProgressBar.setVisibility(View.VISIBLE);
        }else {
            mProgressBar.setVisibility(View.INVISIBLE);
        }
    }
}
