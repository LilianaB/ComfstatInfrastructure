package com.laboratory.thermalcomfort.polar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

/**
 * Created by Liliana Barrios on 22/02/16.
 */
public class PolarAlarmReceiver extends WakefulBroadcastReceiver {

    private static final int FIVE_MINUTES_INTERVAL = 5;
    private static final String TAG = PolarAlarmReceiver.class.getSimpleName();
    public static final int ALARM_ID = 1;

    private AlarmManager mAlarmMgr; // provides access to the system alarm services.
    private PendingIntent mAlarmIntent;// The pending intent, triggered when the alarm fires.

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, PolarSchedulingService.class);
        startWakefulService(context, service);
    }

    public void setAlarm(Context context) {

        long frequency;
        Log.d(TAG, "Set polar alarm");
        frequency = FIVE_MINUTES_INTERVAL * 60 * 1000; //for testing only
        setAlarmHelper(context, frequency);

    }

    private void setAlarmHelper(Context context, long frequency) {
        mAlarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, PolarAlarmReceiver.class);
        mAlarmIntent = PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        // set alarm frequency depending on user preferences
        mAlarmMgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                frequency,
                frequency, mAlarmIntent);
    }

    public void cancelAlarm(Context context) {
        AlarmManager alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, PolarAlarmReceiver.class);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        // If the alarm has been set, cancel it.
        if (alarmMgr!= null) {
            alarmMgr.cancel(alarmIntent);
            alarmIntent.cancel();
            Log.d(TAG, "Cancelled Polar alarm");
        }
    }
}
