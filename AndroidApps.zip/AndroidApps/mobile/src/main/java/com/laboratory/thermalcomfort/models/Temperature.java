package com.laboratory.thermalcomfort.models;

/**
 * Created by Liliana Barrios on 09/03/16.
 */
public class Temperature {

    private int mId;
    private float mDegrees;
    private long mCreationDate;
    private int mSync;

    public Temperature(int id, float degrees, long creationDate, int sync) {
        mId = id;
        mDegrees = degrees;
        mCreationDate = creationDate;
        mSync = sync;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public float getDegrees() {
        return mDegrees;
    }

    public void setDegrees(float degrees) {
        mDegrees = degrees;
    }

    public long getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(long creationDate) {
        mCreationDate = creationDate;
    }

    public int getSync() {
        return mSync;
    }

    public void setSync(int sync) {
        mSync = sync;
    }
}
