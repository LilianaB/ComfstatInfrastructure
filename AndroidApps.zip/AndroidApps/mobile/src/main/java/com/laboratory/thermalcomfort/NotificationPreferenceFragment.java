package com.laboratory.thermalcomfort;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by Liliana Barrios on 09/10/15.
 */
public class NotificationPreferenceFragment extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(android.R.id.content, new PreferenceFragment());
        fragmentTransaction.commit();
    }

}
