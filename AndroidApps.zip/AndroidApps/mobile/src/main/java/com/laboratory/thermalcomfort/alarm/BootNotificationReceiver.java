package com.laboratory.thermalcomfort.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import static com.laboratory.thermalcomfort.utils.Constants.*;

/**
 * Created by Liliana Barrios on 09/10/15.
 */
public class BootNotificationReceiver extends BroadcastReceiver {
    NotificationAlarmReceiver alarm = new NotificationAlarmReceiver();
    private static final String TAG = BootNotificationReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED"))
        {
            alarm.setAlarm(context, NOTIFICATION_FREQUENCY_NONE);
            Log.d(TAG, "Boot Alarm system");
        }
    }
}
