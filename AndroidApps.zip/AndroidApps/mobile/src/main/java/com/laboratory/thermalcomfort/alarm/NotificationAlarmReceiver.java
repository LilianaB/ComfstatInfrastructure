package com.laboratory.thermalcomfort.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;

import com.laboratory.thermalcomfort.utils.NetworkUtil;

import static com.laboratory.thermalcomfort.utils.Constants.*;

/**
 * Created by Liliana Barrios on 09/10/15.
 */
public class NotificationAlarmReceiver extends WakefulBroadcastReceiver {

    private AlarmManager mAlarmMgr; // provides access to the system alarm services.
    private PendingIntent mAlarmIntent;// The pending intent, triggered when the alarm fires.

    public static final int ALARM_ID = 1;

    public static final String TAG = NotificationAlarmReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context, NotificationSchedulingService.class);

        // Start the service, keeping the device awake while it is launching.
        if (NetworkUtil.isConnectedToDesiredWifi(context)) {
            startWakefulService(context, service);
        } else {
            Log.d(TAG, "Not on desired wifi");
        }
    }

    public void setAlarm(Context context, String frequencyTag ) {
        long frequency;

        Log.d(TAG, "inside set alarm");

        switch (frequencyTag) {
            case NOTIFICATION_FREQUENCY_NONE:
                cancelAlarm(context);
                break;
            case NOTIFICATION_FREQUENCY_LOW:
                frequency = AlarmManager.INTERVAL_FIFTEEN_MINUTES;
                setAlarmHelper( context, frequency);
                break;
            case NOTIFICATION_FREQUENCY_MEDIUM:
                frequency = 5 * 60 * 1000; //for testing only
                setAlarmHelper( context, frequency);
                break;
            case NOTIFICATION_FREQUENCY_HIGH:
                frequency = 1 * 60 * 1000; //for testing only
                setAlarmHelper( context, frequency);
                break;
        }
    }

    private void setAlarmHelper(Context context, long frequency) {
        mAlarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationAlarmReceiver.class);
        mAlarmIntent = PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        // set alarm frequency depending on user preferences
        mAlarmMgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,
                frequency,
                frequency, mAlarmIntent);

        // Enable {@code BootNotificationReceiver} to automatically restart the alarm when the
        // device is rebooted.
        ComponentName receiver = new ComponentName(context, BootNotificationReceiver.class);
        PackageManager pm = context.getPackageManager();

        pm.setComponentEnabledSetting(receiver,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP);
    }

    public void cancelAlarm(Context context) {
        AlarmManager alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationAlarmReceiver.class);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(context, ALARM_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        // If the alarm has been set, cancel it.
        if (alarmMgr!= null) {
            alarmMgr.cancel(alarmIntent);
            alarmIntent.cancel();
            Log.d(TAG, "Cancelled notification alarm");
        }

        // Disable {@code BootNotificationReceiver} so that it doesn't automatically restart the
        // alarm when the device is rebooted.
        ComponentName receiver = new ComponentName(context, BootNotificationReceiver.class);
        PackageManager pm = context.getPackageManager();

        pm.setComponentEnabledSetting(receiver,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }
}
