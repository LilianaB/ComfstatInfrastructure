package com.laboratory.thermalcomfort.models;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Liliana Barrios on 18/10/15.
 */
public class Environment {

    private double mTemperature;
    private double mHumidity;
    private double mPressure;
    private long mTime;


    public int getTemperature() {
        return (int)Math.round(mTemperature);
    }

    public void setTemperature(double temperature) {
        mTemperature = temperature;
    }

    public double getHumidity() {
        return mHumidity;
    }

    public void setHumidity(double humidity) {
        mHumidity = humidity;
    }

    public double getPressure() {
        return mPressure;
    }

    public void setPressure(double pressure) {
        mPressure = pressure;
    }

    public long getTime() {
        return mTime;
    }

    public void setTime(long time) {
        mTime = time;
    }

    public String getFormattedTime() {
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        TimeZone timeZone = TimeZone.getTimeZone("Europe/Zurich");
        formatter.setTimeZone(timeZone);
        Date date = new Date(getTime() * 1000); //mTime in sec but we need milisec
        return formatter.format(date);


    }
}
