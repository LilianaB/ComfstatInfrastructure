package com.laboratory.thermalcomfort.alarm;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.wearable.MessageApi;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.Wearable;
import com.laboratory.thermalcomfort.R;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;

import static com.laboratory.thermalcomfort.utils.Constants.*;

/**
 * Created by Liliana Barrios on 18/11/15.
 */
public class HeartRateSchedulingService extends IntentService implements
        MessageApi.MessageListener, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {


    private GoogleApiClient mGoogleApiClient;
    private String mHeartRate;
    private String mBattery;
    private String mElapsedTime;
    private String mAccuracy;
    private String mRaspberryPiUrl;

    public HeartRateSchedulingService() {
        super("HeartRateSchedulingService");
    }

    public static final String TAG = HeartRateSchedulingService.class.getSimpleName();

    @Override public void onCreate() {
        super.onCreate();
        initGooglePlayServices();
        mGoogleApiClient.connect();
        Log.d(TAG, "Creating service.");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
        mGoogleApiClient.connect();

        Log.d(TAG, "Generating RPC: heart-rate service");
        // "start-activity" message to each connected node.
        Collection<String> nodes = getNodes();
        for (String node : nodes) {
            Log.d(TAG, node.toString());
            sendStartHeartRateServiceMessage(node);
        }
        //todo check why this is notificationAlarmReceiver
        // Release the wake lock provided by the castReceiver.
        NotificationAlarmReceiver.completeWakefulIntent(intent);
    }

    @Override
    public void onConnected(Bundle bundle) {
        Log.d(TAG, "Google API Client was connected");
        Wearable.MessageApi.addListener(mGoogleApiClient, this);
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d(TAG, "Connection to Google API client was suspended");
    }

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {
        mGoogleApiClient.disconnect(); //after heart-rate is received, free googleApiClient

        String path = messageEvent.getPath().toString();
        final String message = new String(messageEvent.getData());
        Log.d(TAG, "onMessageReceived():" + messageEvent
                .getRequestId() + " " + messageEvent.getPath() + " " + message);

        processMessage(message);
        if (path.equals(START_SERVICE_PATH)) {


            if (NetworkUtil.isNetworkAvailable(this)) {
                OkHttpClient client = new OkHttpClient();
                String raspberryURL = buildURL();

                JSONObject jsonData = new JSONObject();

                try {
                    jsonData.put(HEART_RATE, mHeartRate);
                    jsonData.put(CREATION_TIME, TimeUtil.currentTime());
                    jsonData.put(BATTERY, mBattery);
                    jsonData.put(USER_ID, getCurrentUserId());
                    jsonData.put(ELAPSED_TIME, mElapsedTime);
                    jsonData.put(ACCURACY, mAccuracy);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
                Request request = new Request.Builder()
                        .url(raspberryURL)
                        .addHeader("Content-Type", "text/json; Charset=UTF-8")
                        .post(body)
                        .build();

                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(Request request, IOException e) {
                        Log.e(TAG, "Failed to connect to server " + e.getMessage());
                    }

                    @Override
                    public void onResponse(Response response) throws IOException {
                        if (response.isSuccessful()) {
                            Log.d(TAG, "Message sent to server");
                        } else {
                            Log.e(TAG, "Response unsuccessful");
                        }
                    }
                });
            } else {
                Toast.makeText(this, getString(R.string.network_unavailable_message),
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.e(TAG, "Connection to Google API client has failed");
        Wearable.MessageApi.removeListener(mGoogleApiClient, this);
    }

    private void processMessage(String message) {
        String[] separated = message.split(TOKEN);
        mHeartRate = separated[0];
        mBattery = separated[1];
        mElapsedTime = separated[2];
        mAccuracy = separated[3];
    }

    private Collection<String> getNodes() {

        HashSet<String> results = new HashSet<>();
        NodeApi.GetConnectedNodesResult nodes =
                Wearable.NodeApi.getConnectedNodes(mGoogleApiClient).await();

        for (Node node : nodes.getNodes()) {
            results.add(node.getId());
        }

        return results;
    }

    private void sendStartHeartRateServiceMessage(String node) {
        Log.d(TAG, "sending message to wear");
        String msg = "message from mobile with DataLayer";
        Wearable.MessageApi.sendMessage(
                mGoogleApiClient, node, START_SERVICE_PATH, msg.getBytes()).setResultCallback(
                new ResultCallback<MessageApi.SendMessageResult>() {
                    @Override
                    public void onResult(MessageApi.SendMessageResult sendMessageResult) {
                        if (!sendMessageResult.getStatus().isSuccess()) {
                            Log.e(TAG, "Failed to send message with status code: "
                                    + sendMessageResult.getStatus().getStatusCode());
                        } else {
                            Log.d(TAG, "SUCCESS");
                        }
                    }
                }
        );
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/environment";
    }

    private int getCurrentUserId() {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        return sharedPref.getInt(getString(R.string.pref_current_user_id), 0);
    }

    private void initGooglePlayServices() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(Wearable.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
    }

}


