package com.laboratory.thermalcomfort.models;

/**
 * Created by Liliana Barrios on 21/03/16.
 */
public class Wifi {

    private int mId;
    private String mConnectedTo;
    private String mAvailableWifi;
    private long mCreationDate;
    private int mSync;

    public Wifi(int id, String connectedTo, String availableWifi, long creationDate) {
        mId = id;
        mConnectedTo = connectedTo;
        mAvailableWifi = availableWifi;
        mCreationDate = creationDate;
    }

    public Wifi(int id, String connectedTo, String availableWifi, long creationDate, int sync) {
        mId = id;
        mConnectedTo = connectedTo;
        mAvailableWifi = availableWifi;
        mCreationDate = creationDate;
        mSync = sync;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public String getConnectedTo() {
        return mConnectedTo;
    }

    public void setConnectedTo(String connectedTo) {
        mConnectedTo = connectedTo;
    }

    public String getAvailableWifi() {
        return mAvailableWifi;
    }

    public void setAvailableWifi(String availableWifi) {
        mAvailableWifi = availableWifi;
    }

    public long getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(long creationDate) {
        mCreationDate = creationDate;
    }

    public int getSync() {
        return mSync;
    }

    public void setSync(int sync) {
        mSync = sync;
    }
}
