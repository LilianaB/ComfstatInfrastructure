package com.laboratory.thermalcomfort;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.RemoteInput;
import android.util.Log;
import android.widget.Toast;

import com.laboratory.thermalcomfort.alarm.NotificationSchedulingService;
import com.laboratory.thermalcomfort.models.ThermalComfort;
import com.laboratory.thermalcomfort.utils.NotificationUtil;
import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.SessionUtil;
import com.laboratory.thermalcomfort.utils.TimeUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

/**
 * Broadcast receiver to post toast messages in response to notification intents firing.
 */
public class NotificationIntentReceiver extends BroadcastReceiver {

    public static final String ACTION_EXAMPLE = "com.laboratory.thermalcomfort.ACTION_EXAMPLE";
    private static final String TAG = NotificationIntentReceiver.class.getSimpleName();

    private String mRaspberryPiUrl;

    @Override
    public void onReceive(Context context, Intent intent) {
        mRaspberryPiUrl = NetworkUtil.getUserPreferences(context);
        cancelWearNotification(context);

        Log.d(NotificationIntentReceiver.class.getSimpleName(), "on receive");
        if (intent.getAction().equals(ACTION_EXAMPLE)) {
                String message = intent.getStringExtra(NotificationUtil.EXTRA_MESSAGE);
                Bundle remoteInputResults = RemoteInput.getResultsFromIntent(intent);
                CharSequence replyMessage = null;
                if (remoteInputResults != null) {
                    replyMessage = remoteInputResults.getCharSequence(NotificationUtil.EXTRA_REPLY);
                }
                if (replyMessage != null) {
                    Log.d(TAG, "Comfort from watch "+replyMessage);
                    int ashrae = ThermalComfort.getAshrae(replyMessage.toString());

                    if (NetworkUtil.isNetworkAvailable(context)) {
                        OkHttpClient client = new OkHttpClient();
                        String raspberryURL = buildURL();

                        JSONObject jsonData = new JSONObject();

                        try {
                            jsonData.put(ThermalComfortActivity.USER_ID, SessionUtil.getCurrentUserId(context));
                            jsonData.put(ThermalComfortActivity.CREATION_TIME, TimeUtil.currentTime());
                            jsonData.put(ThermalComfortActivity.COMFORT_LEVEL, ashrae);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
                        Request request = new Request.Builder()
                                .url(raspberryURL)
                                .addHeader("Content-Type","text/json; Charset=UTF-8")
                                .post(body)
                                .build();

                        Call call = client.newCall(request);
                        call.enqueue(new Callback() {
                            @Override
                            public void onFailure(Request request, IOException e) {
                                Log.e(TAG, "Failed to connect to server " + e.getMessage());
                            }

                            @Override
                            public void onResponse(Response response) throws IOException {

                                try {
                                    String jsonWeatherData = response.body().string();
                                    if (response.isSuccessful()) {
                                        Log.d(TAG, "Created comfort record on server");
                                    } else {
                                        Log.e(TAG, "Response unsuccessful");
                                    }
                                } catch (IOException e) {
                                    Log.e(TAG, "Exception caught:", e);
                                }
                            }
                        });
                    } else {
                        Toast.makeText(context, context.getString(R.string.network_unavailable_message),
                                Toast.LENGTH_LONG).show();
                    }
                }
        }
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/vote";
    }

    private void cancelWearNotification(Context context) {
        NotificationManager mNotificationManager = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancel(NotificationSchedulingService.NOTIFICATION_ID);
    }
}
