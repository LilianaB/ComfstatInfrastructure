package com.laboratory.thermalcomfort;

/**
 * Created by Liliana Barrios on 24/09/15.
 */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.laboratory.thermalcomfort.utils.NetworkUtil;
import com.laboratory.thermalcomfort.utils.SessionUtil;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class SignUpActivity extends Activity {

    private static String USERNAME = "username";
    private static String SEX = "sex";
    private static String WEIGHT = "weight";
    private static String HEIGHT = "height";
    private static String PASS = "password";
    private static String BIRTHDAY = "birthday";

    final static String TAG = SignUpActivity.class.getSimpleName();
    private String mRaspberryPiUrl;

    @Bind(R.id.usernameEditText) EditText mUsername;
    @Bind(R.id.sexRadioGroup) RadioGroup mSexGroup;
    @Bind(R.id.birthdayEditText) EditText mBirthday;
    @Bind(R.id.weightEditText) EditText mWeight;
    @Bind(R.id.heightEditText) EditText mHeight;
    @Bind(R.id.passwordEditText) EditText mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        getActionBar().hide();
        ButterKnife.bind(this);
        mRaspberryPiUrl = NetworkUtil.getUserPreferences(this);
    }

    @OnClick(R.id.signupButton)
    public void validate() {
        String username = mUsername.getText().toString();
        int sexGroup = mSexGroup.getCheckedRadioButtonId();
        String birthday = mBirthday.getText().toString();
        String password = mPassword.getText().toString();
        String weight = mWeight.getText().toString();
        String height = mHeight.getText().toString();

        if (username.isEmpty() || sexGroup == -1  || birthday.isEmpty() || password.isEmpty() || weight.isEmpty() || height.isEmpty()){
            AlertDialog.Builder builder = new AlertDialog.Builder(SignUpActivity.this);
            builder.setMessage(R.string.signup_error_message)
                    .setTitle(R.string.login_error_title)
                    .setPositiveButton(android.R.string.ok, null);
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {

            long birthdayLong = parseBirthday(birthday);

            if (!isBirthdayValid(birthdayLong)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SignUpActivity.this);
                builder.setMessage(R.string.signup_invalid_date_format)
                        .setTitle(R.string.login_error_title)
                        .setPositiveButton(android.R.string.ok, null);
                AlertDialog dialog = builder.create();
                dialog.show();
            } else {
                setProgressBarIndeterminateVisibility(true);//show progressbar


                    RadioButton radioSexButton = (RadioButton) findViewById(sexGroup);
                    String sex = radioSexButton.getText().toString();


                    if (NetworkUtil.isNetworkAvailable(this)) {
                        Log.d(TAG, "Sending data to server");
                        OkHttpClient client = new OkHttpClient();
                        String raspberryURL = buildURL();

                        JSONObject jsonData = new JSONObject();
                        try {
                            jsonData.put(USERNAME, username);
                            jsonData.put(SEX, sex);
                            jsonData.put(WEIGHT, weight);
                            jsonData.put(HEIGHT, height);
                            jsonData.put(PASS, password);
                            jsonData.put(BIRTHDAY, parseBirthday(birthday));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        RequestBody body = RequestBody.create(NetworkUtil.JSON, jsonData.toString());
                        final Request request = new Request.Builder()
                                .url(raspberryURL)
                                .addHeader("Content-Type","text/json; Charset=UTF-8")
                                .post(body)
                                .build();

                        Call call = client.newCall(request);
                        call.enqueue(new Callback() {
                            @Override
                            public void onFailure(Request request, IOException e) {
                                Log.e(TAG,"Failed to connect to server "+ e.getMessage());
                            }

                            @Override
                            public void onResponse(Response response) throws IOException {

                                try {
                                    if (response.isSuccessful()) {
                                        //do something
                                        Log.d(TAG, "Successfully added new user to server");
                                        //TODO get user id, intent redirect to main menu, add id to shared preferences
                                        String jsonData = response.body().string();
                                        JSONObject userData = null;
                                        try {
                                            userData = new JSONObject(jsonData);
                                            Log.d(TAG, "User id: "+ userData.getInt("id"));
                                            saveSessionValues(userData.getInt("id"), true);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                        navegateToMain();

                                    } else {
                                        Log.e(TAG, "Response unsuccessful "+ response.code());
                                    }
                                } catch (IOException e) {
                                    Log.e(TAG, "Exception caught:", e);
                                }
                            }
                        });
                    } else {
                        Toast.makeText(this, getString(R.string.network_unavailable_message),
                                Toast.LENGTH_LONG).show();
                    }

                    setProgressBarIndeterminateVisibility(false);//show progressbar

                }


        }
    }

    private boolean isBirthdayValid(long birthday) {
        return birthday != 0L;
    }

    private long parseBirthday(String birthday) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.GERMANY);
        long milliseconds = 0L;
        Date date;
        try {
            date = sdf.parse(birthday);
            milliseconds = date.getTime();
            Log.d(TAG, date.toString());
        } catch (ParseException e) {
            Log.e(TAG, e.getMessage());
        }

        return milliseconds/1000L;
    }

    @OnClick(R.id.cancelButton)
    public void backToMain() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    private String buildURL() {
        return "http://"+mRaspberryPiUrl+ "/ComfStat/user";
    }

    private void navegateToMain() {

        SessionUtil sessionUtil = new SessionUtil();
        sessionUtil.startServices(this, TAG);

        Intent intent = new Intent(this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void saveSessionValues(int id, boolean isLogged) {
        SharedPreferences sharedPref = getSharedPreferences(
                "com.laboratory.thermalcomfort.GLOBAL", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(getString(R.string.pref_current_user_id), id);
        editor.putBoolean(getString(R.string.pref_is_user_logged), isLogged);
        editor.commit();
    }
}
