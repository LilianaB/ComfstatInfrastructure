package com.laboratory.thermalcomfort.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import com.laboratory.thermalcomfort.models.Battery;
import com.laboratory.thermalcomfort.models.Wifi;

import java.util.ArrayList;

/**
 * Created by Liliana Barrios on 21/03/16.
 */
public class WifiDataSource {

    private DBSqliteHelper mDBSqliteHelper;
    private static final String TAG = WifiDataSource.class.getSimpleName();

    public WifiDataSource(Context context) {
        mDBSqliteHelper = new DBSqliteHelper(context);
    }

    private SQLiteDatabase open() {
        return mDBSqliteHelper.getWritableDatabase();
    }

    private void close(SQLiteDatabase db) {
        db.close();
    }

    public ArrayList<Wifi> read() {
        SQLiteDatabase db = open();

        db.beginTransaction();

        Cursor cursor = db.query(
                DBSqliteHelper.WIFI_TABLE,
                new String[]{BaseColumns._ID, DBSqliteHelper.COLUMN_WIFI_CONNECTED_TO,
                        DBSqliteHelper.COLUMN_WIFI_AVAILABLE_WIFI,DBSqliteHelper.COLUMN_WIFI_CREATION_DATE ,
                        DBSqliteHelper.COLUMN_BATTERY_SYNC},
                null, //selection
                null, //selection args
                null, //group by
                null, //having
                null); //order

        ArrayList<Wifi> wifiRecords = new ArrayList<Wifi>();
        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                Wifi wifi = new Wifi(DBHelper.getIntFromColumnName(cursor, BaseColumns._ID),
                        DBHelper.getStringFromColumnName(cursor, DBSqliteHelper.COLUMN_WIFI_CONNECTED_TO),
                        DBHelper.getStringFromColumnName(cursor, DBSqliteHelper.COLUMN_WIFI_AVAILABLE_WIFI),
                        DBHelper.getLongFromColumnName(cursor, DBSqliteHelper.COLUMN_WIFI_CREATION_DATE),
                        DBHelper.getIntFromColumnName(cursor, DBSqliteHelper.COLUMN_WIFI_SYNC)
                );
                wifiRecords.add(wifi);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
        return wifiRecords;
    }

    public  Cursor getCursor() {

        SQLiteDatabase db = open();

        String whereClause = DBSqliteHelper.COLUMN_WIFI_SYNC + "=?";

        Cursor cursor = db.query(
                DBSqliteHelper.WIFI_TABLE,
                new String[]{BaseColumns._ID, DBSqliteHelper.COLUMN_WIFI_CONNECTED_TO,
                        DBSqliteHelper.COLUMN_WIFI_AVAILABLE_WIFI ,  DBSqliteHelper.COLUMN_WIFI_CREATION_DATE, DBSqliteHelper.COLUMN_WIFI_SYNC},
                whereClause,
                new String[] {String.valueOf(0)},
                null, //group by
                null, //having
                null); //order
        //db.close();
        return cursor;
    }

    public void update(Cursor cursor) {
        Log.d(TAG, "Updating Records");

        SQLiteDatabase db = open();
        db.beginTransaction();

        if (cursor.moveToFirst()) { //move to first is elements exists
            do {
                int recordId = DBHelper.getIntFromColumnName(cursor, BaseColumns._ID);
                ContentValues cv = new ContentValues();
                cv.put(DBSqliteHelper.COLUMN_WIFI_SYNC,1);
                db.update(DBSqliteHelper.WIFI_TABLE,
                        cv,
                        "_id="+recordId,
                        null);
            }while(cursor.moveToNext()); //loop while there are elements
        }
        cursor.close();

        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
    }

    public long create(Wifi wifi) {
        SQLiteDatabase db = open();
        db.beginTransaction();

        ContentValues wifiValues = new ContentValues();
        wifiValues.put(DBSqliteHelper.COLUMN_WIFI_CONNECTED_TO, wifi.getConnectedTo());
        wifiValues.put(DBSqliteHelper.COLUMN_WIFI_AVAILABLE_WIFI, wifi.getAvailableWifi());
        wifiValues.put(DBSqliteHelper.COLUMN_WIFI_CREATION_DATE, wifi.getCreationDate());
        wifiValues.put(DBSqliteHelper.COLUMN_BATTERY_SYNC, 0);
        long id = db.insert(DBSqliteHelper.WIFI_TABLE, null, wifiValues);

        db.setTransactionSuccessful();
        db.endTransaction();
        close(db);

        return id;
    }
}
