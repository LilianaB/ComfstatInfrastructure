package com.laboratory.thermalcomfort.models;

/**
 * Created by Liliana Barrios on 09/03/16.
 */
public class Battery {

    private int mId;
    private int mLevel;
    private long mCreationDate;
    private int mSync;

    public Battery(int id, int level, long creationDate, int sync) {
        mId = id;
        mLevel = level;
        mCreationDate = creationDate;
        mSync = sync;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public int getLevel() {
        return mLevel;
    }

    public void setLevel(int level) {
        mLevel = level;
    }

    public long getCreationDate() {
        return mCreationDate;
    }

    public void setCreationDate(long creationDate) {
        mCreationDate = creationDate;
    }

    public int getSync() {
        return mSync;
    }

    public void setSync(int sync) {
        mSync = sync;
    }

}
